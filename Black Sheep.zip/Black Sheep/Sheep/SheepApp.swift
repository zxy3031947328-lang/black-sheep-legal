//
//  SheepApp.swift
//  Black Sheep
//
//  Created by 曾鑫宇 on 2026/2/26.
//

import SwiftUI
import FirebaseCore

@main
struct BlackSheepApp: App {
    @State private var showSplash = true
    @State private var splashOpacity = 1.0 // Control opacity of SplashView manually
    @Environment(\.scenePhase) private var scenePhase
    
    init() {
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            ZStack {
                // Main Content (Always underneath)
                ContentView()
                    .zIndex(0)

                // Splash Screen (On top)
                if showSplash {
                    SplashView {
                        // When SplashView finishes its internal animation (2.0s):
                        // 1. Fade out the entire SplashView (including white background)
                        withAnimation(.easeOut(duration: 1.0)) {
                            splashOpacity = 0.0
                        }
                        
                        // 2. Remove from hierarchy after fade out completes
                        // Give it a bit more time (1.2s) to ensure animation finishes
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                            showSplash = false
                        }
                    }
                    .opacity(splashOpacity) // Bind opacity
                    .animation(.easeOut(duration: 1.0), value: splashOpacity) // Explicit animation
                    .zIndex(1)
                }
            }
            .onChange(of: scenePhase) { _, newPhase in
                if newPhase == .active {
                    // Reset splash when returning from background
                    // Uncomment the next line if you want splash on EVERY return
                    // showSplash = true 
                }
            }
        }
    }
}
