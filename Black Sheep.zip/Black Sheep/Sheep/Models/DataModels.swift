import Foundation

// MARK: - Data Transfer Objects (DTOs) matching JSON structure

// MARK: - New Atomic DTOs (Multi-file Architecture)

// 1. Index (index.json)
struct LawIndexRootDTO: Codable {
    let category: String
    let laws: [LawIndexItemDTO]
}

struct LawIndexItemDTO: Codable {
    let id: String
    let name: String
    let createdAt: String?
    let updatedAt: String?
}

// 2. Base (base.json)
struct LawBaseDTO: Codable {
    let name: String
    let micro: [String]?
    let summary: String?
    // Backward compatibility if needed
    let quote: String?
    let theory: String?
    
    var safeQuote: String {
        if let m = micro, !m.isEmpty { return m[0] }
        return quote ?? ""
    }
    
    var safeSummary: String {
        return summary ?? theory ?? ""
    }
}

// 3. Encyclopedia (encyclopedia.json)
struct EncyclopediaDTO: Codable {
    let originYear: Int?
    let researcher: String?
    let background: String?
    let detailedInterpretation: String?
    let howToDetect: [String]?
    let howToApply: [String]?
    let boundaries: [String]?
    
    enum CodingKeys: String, CodingKey {
        case originYear = "origin_year"
        case researcher
        case background
        case detailedInterpretation = "detailed_interpretation"
        case howToDetect = "how_to_detect"
        case howToApply = "how_to_apply"
        case boundaries
    }
    
    func toSource() -> Law.LawSource {
        Law.LawSource(
            originYear: originYear,
            researcher: researcher,
            background: background
        )
    }
    
    func toDeepDive() -> Law.LawDeepDive {
        Law.LawDeepDive(
            detailedInterpretation: detailedInterpretation ?? "",
            howToDetect: howToDetect ?? [],
            howToApply: howToApply ?? [],
            boundaries: boundaries ?? []
        )
    }
}

// 4. Day Simulation (day1.json, day2.json, day3.json)
struct DaySimulationDTO: Codable {
    let day: String // "day1"
    let title: String
    let practice: String?
    let simulations: [SimulationDTO]
    
    func toDomain(dayNum: Int) -> Law.DayContent {
        Law.DayContent(
            dayNumber: dayNum,
            title: title,
            actionGuide: practice ?? "",
            simulations: simulations.map { $0.toDomain() }
        )
    }
}

// MARK: - Legacy / Helper DTOs (Keep Simulation/Option)

struct SimulationDTO: Codable {
    let id: String
    // Type might be missing in some files, default to identification
    let type: String?
    let text: String
    let options: [OptionDTO]
    
    func toDomain() -> Scenario {
        let scenarioType: ScenarioType
        if let t = type {
            switch t {
            case "identification": scenarioType = .identification
            case "experiment": scenarioType = .experiment
            case "boundary": scenarioType = .conflict
            default: scenarioType = .identification
            }
        } else {
            scenarioType = .identification
        }
        
        return Scenario(
            id: id,
            type: scenarioType,
            text: text,
            options: options.map { $0.toDomain() }
        )
    }
}

struct OptionDTO: Codable {
    let text: String
    // Support both new "result_line" and old "feedback"
    let resultLine: String?
    let feedback: String?
    
    let scoreImpact: ScoreImpactDTO?
    
    enum CodingKeys: String, CodingKey {
        case text
        case resultLine = "result_line"
        case feedback
        case scoreImpact = "score_impact"
    }
    
    func toDomain() -> RPGOption {
        let outcome = resultLine ?? feedback ?? ""
        let impact = scoreImpact?.toDomain() ?? .zero
        
        return RPGOption(
            text: text,
            scoreImpact: impact,
            outcomeText: outcome
        )
    }
}

struct ScoreImpactDTO: Codable {
    let reflection: Double?
    let objectivity: Double?
    let independence: Double?
    let decisiveness: Double?
    let awareness: Double?
    
    enum CodingKeys: String, CodingKey {
        case reflection = "反思"
        case objectivity = "客观"
        case independence = "独立"
        case decisiveness = "决断"
        case awareness = "觉察"
    }
    
    func toDomain() -> MindPentagon {
        return MindPentagon(
            objectivity: objectivity ?? 0,
            independence: independence ?? 0,
            awareness: awareness ?? 0,
            decisiveness: decisiveness ?? 0,
            reflection: reflection ?? 0
        )
    }
}
