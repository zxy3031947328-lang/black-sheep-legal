import Foundation

// MARK: - Mind Pentagon (Five Dimensions)
struct MindPentagon: Codable, Equatable {
    var objectivity: Double = 400.0   // 客观
    var independence: Double = 400.0  // 独立
    var awareness: Double = 400.0     // 觉察
    var decisiveness: Double = 400.0  // 决断
    var reflection: Double = 400.0    // 反思
    
    // Helper to add scores
    static func + (lhs: MindPentagon, rhs: MindPentagon) -> MindPentagon {
        return MindPentagon(
            objectivity: lhs.objectivity + rhs.objectivity,
            independence: lhs.independence + rhs.independence,
            awareness: lhs.awareness + rhs.awareness,
            decisiveness: lhs.decisiveness + rhs.decisiveness,
            reflection: lhs.reflection + rhs.reflection
        )
    }
    
    static func * (lhs: MindPentagon, rhs: Double) -> MindPentagon {
        MindPentagon(
            objectivity: lhs.objectivity * rhs,
            independence: lhs.independence * rhs,
            awareness: lhs.awareness * rhs,
            decisiveness: lhs.decisiveness * rhs,
            reflection: lhs.reflection * rhs
        )
    }
    
    static let zero = MindPentagon(
        objectivity: 0,
        independence: 0,
        awareness: 0,
        decisiveness: 0,
        reflection: 0
    )
    
    func clamped(min minValue: Double, max maxValue: Double) -> MindPentagon {
        MindPentagon(
            objectivity: min(max(objectivity, minValue), maxValue),
            independence: min(max(independence, minValue), maxValue),
            awareness: min(max(awareness, minValue), maxValue),
            decisiveness: min(max(decisiveness, minValue), maxValue),
            reflection: min(max(reflection, minValue), maxValue)
        )
    }
    
    var positiveSum: Double {
        max(0, objectivity) + max(0, independence) + max(0, awareness) + max(0, decisiveness) + max(0, reflection)
    }
}

// MARK: - Law Category
enum LawCategory: String, Codable, CaseIterable {
    case socialInfluence = "social_influence" // 社会影响心理 (1)
    case moneyPsych = "money_psychology"       // 金钱与经济心理 (2)
    case powerStructure = "power_structure" // 权利与层级结构 (3)
    case decisionMaking = "decision_making" // 决策与认知偏差 (4)
    case selfStructure = "self_structure"   // 自我与认知结构 (5)
    case emotionManipulation = "emotion_manipulation" // 情绪与操控机制 (6)
    case relationshipGame = "relationship_game" // 关系与博弈心理 (7)
    case infoManipulation = "info_manipulation" // 信息操控和舆论结构 (8)
    
    var displayName: String {
        switch self {
        case .socialInfluence: return "社会影响心理"
        case .moneyPsych: return "金钱与经济心理"
        case .powerStructure: return "权利与层级结构"
        case .decisionMaking: return "决策与认知偏差"
        case .selfStructure: return "自我与认知结构"
        case .emotionManipulation: return "情绪与操控机制"
        case .relationshipGame: return "关系与博弈心理"
        case .infoManipulation: return "信息操控和舆论结构"
        }
    }
}

// MARK: - Law (v3 - Experiment Manual)
struct Law: Identifiable, Codable {
    let id: String
    let name: String
    let category: LawCategory // New field
    let scenarioID: String
    let dailyQuote: String // "Qi Xia" style short quote
    let detailText: String // Theory explanation
    let experimentGuide: String // General guide on how to use this law active/passively
    
    // New Fields for Detailed Content
    let source: LawSource?
    let deepDive: LawDeepDive?
    
    // Content per day (Day 1, 2, 3)
    let dayStages: [DayContent]
    
    struct LawSource: Codable {
        let originYear: Int?
        let researcher: String?
        let background: String?
    }
    
    struct LawDeepDive: Codable {
        let detailedInterpretation: String
        let howToDetect: [String]
        let howToApply: [String]
        let boundaries: [String]
    }
    
    struct DayContent: Codable {
        let dayNumber: Int
        let title: String // e.g., "Day 1: Observation"
        let actionGuide: String // Specific instruction for today's experiment
        let simulations: [Scenario] // Changed to array for random rotation
    }
    
    var displayChineseName: String {
        splitDisplayName.chinese
    }
    
    var displayEnglishName: String {
        let explicitEnglish = splitDisplayName.english
        if !explicitEnglish.isEmpty {
            return explicitEnglish
        }
        if let mappedEnglish = Self.curatedEnglishNameMap[displayChineseName] {
            return mappedEnglish
        }
        return fallbackEnglishNameFromID()
    }
    
    private static let curatedEnglishNameMap: [String: String] = [
        "社会比较理论": "Social Comparison Theory",
        "诱饵效应": "Decoy Effect",
        "折中效应": "Compromise Effect",
        "确认偏误": "Confirmation Bias",
        "框架效应": "Framing Effect",
        "可得性启发": "Availability Heuristic",
        "过度自信偏差": "Overconfidence Bias",
        "控制错觉": "Illusion of Control",
        "决策疲劳": "Decision Fatigue",
        "归因偏差": "Attribution Bias",
        "自利偏差": "Self-Serving Bias",
        "虚假共识效应": "False Consensus Effect",
        "黑白思维": "Black-and-White Thinking",
        "基率忽视": "Base Rate Neglect",
        "后见之明偏差": "Hindsight Bias",
        "自证预言": "Self-Fulfilling Prophecy",
        "认知失调": "Cognitive Dissonance",
        "投射效应": "Projection",
        "自我妨碍": "Self-Handicapping",
        "习得性无助": "Learned Helplessness",
        "冒名顶替综合征": "Impostor Syndrome",
        "聚光灯效应": "Spotlight Effect",
        "反刍思维": "Rumination",
        "补偿心理": "Compensatory Psychology",
        "内摄效应": "Introjection",
        "完美主义": "Perfectionism",
        "自我验证效应": "Self-Verification Effect",
        "情绪感染": "Emotional Contagion",
        "情感勒索": "Emotional Blackmail",
        "间歇性奖励": "Intermittent Reinforcement",
        "恐惧诉求": "Fear Appeal",
        "羞耻诱发": "Shame Induction",
        "愧疚诱导": "Guilt Induction",
        "情绪降级": "Emotional Devaluation",
        "安全感构建": "Sense of Safety Building",
        "情感镜映": "Emotional Mirroring",
        "预期管理": "Expectation Management",
        "情绪调节引导": "Emotion Regulation Guidance",
        "情绪启动效应": "Affective Priming",
        "囚徒困境": "Prisoner's Dilemma",
        "边界试探": "Boundary Testing",
        "承诺升级": "Escalation of Commitment",
        "三角关系操控": "Triangulation",
        "互惠失衡": "Reciprocity Imbalance",
        "替代性依赖": "Substitute Dependency",
        "联盟偏向": "Alliance Bias",
        "关系去激活策略": "Relationship Deactivation Strategy",
        "投射性认同": "Projective Identification",
        "忠诚测试": "Loyalty Test",
        "责任转嫁": "Responsibility Shifting",
        "位置不对称": "Positional Asymmetry",
        "信息茧房": "Information Cocoon",
        "沉默的螺旋": "Spiral of Silence",
        "选择性呈现": "Selective Presentation",
        "标签化叙事": "Labeling Narrative",
        "回音室效应": "Echo Chamber Effect",
        "伪共识制造": "Manufactured Consensus",
        "伪专业背书": "Pseudo-Expert Endorsement",
        "注意力劫持": "Attention Hijacking",
        "信息过载麻木": "Information Overload Numbing",
        "真假混杂策略": "Truth-Falsehood Blending Strategy",
        "可见性偏差": "Visibility Bias",
        "叙事嫁接": "Narrative Grafting",
        "权力距离指数": "Power Distance Index",
        "信息垄断效应": "Information Monopoly Effect",
        "议程设定效应": "Agenda-Setting Effect",
        "关键节点控制": "Key Node Control",
        "替代性稀缺原则": "Substitute Scarcity Principle",
        "默认中心效应": "Default Centrality Effect",
        "资源入口控制": "Resource Gatekeeping",
        "注意力分配权": "Attention Allocation Power",
        "结构缓冲位": "Structural Buffer Position",
        "非正式权威": "Informal Authority",
        "马太效应": "Matthew Effect",
        "代理人困境": "Principal-Agent Dilemma"
    ]
    
    private var splitDisplayName: (chinese: String, english: String) {
        let name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if let start = name.firstIndex(of: "("), let end = name[start...].firstIndex(of: ")") {
            let chinese = name[..<start].trimmingCharacters(in: .whitespacesAndNewlines)
            let english = name[name.index(after: start)..<end].trimmingCharacters(in: .whitespacesAndNewlines)
            return (chinese.isEmpty ? name : chinese, english)
        }
        
        if let start = name.firstIndex(of: "（"), let end = name[start...].firstIndex(of: "）") {
            let chinese = name[..<start].trimmingCharacters(in: .whitespacesAndNewlines)
            let english = name[name.index(after: start)..<end].trimmingCharacters(in: .whitespacesAndNewlines)
            return (chinese.isEmpty ? name : chinese, english)
        }
        
        return (name, "")
    }
    
    private func fallbackEnglishNameFromID() -> String {
        let parts = id.split(separator: "_").map(String.init)
        guard !parts.isEmpty else { return "Mechanism" }
        
        var trimmed = parts
        if trimmed.first == "law" {
            trimmed.removeFirst()
        }
        
        let categoryPrefix: [String]
        switch category {
        case .socialInfluence:
            categoryPrefix = ["social"]
        case .moneyPsych:
            categoryPrefix = ["money"]
        case .powerStructure:
            categoryPrefix = ["power"]
        case .decisionMaking:
            categoryPrefix = ["decision"]
        case .selfStructure:
            categoryPrefix = ["self"]
        case .emotionManipulation:
            categoryPrefix = ["emotion"]
        case .relationshipGame:
            categoryPrefix = ["relationship"]
        case .infoManipulation:
            categoryPrefix = ["info"]
        }
        
        if trimmed.starts(with: categoryPrefix) {
            trimmed.removeFirst(categoryPrefix.count)
        }
        
        let suffixNumber = trimmed.last?.allSatisfy(\.isNumber) == true ? trimmed.removeLast() : nil
        let words = trimmed.map { word in
            word.split(separator: "-").map { chunk in
                chunk.prefix(1).uppercased() + chunk.dropFirst().lowercased()
            }.joined(separator: "-")
        }
        
        if !words.isEmpty {
            return words.joined(separator: " ")
        }
        
        if let suffixNumber {
            return "Mechanism \(suffixNumber)"
        }
        
        return "Mechanism"
    }
}

// MARK: - Scenario (Micro-Novel Simulation)
enum ScenarioType: String, Codable {
    case identification // 识别型
    case experiment     // 实验型
    case conflict       // 边界冲突型
}

struct Scenario: Identifiable, Codable {
    let id: String
    let type: ScenarioType
    let text: String // The micro-novel story text (120-180 words)
    let options: [RPGOption]
    
    // Computed property for backward compatibility if needed, or just for display
    var title: String {
        switch type {
        case .identification: return "微小说：识别"
        case .experiment: return "微小说：实验"
        case .conflict: return "微小说：博弈"
        }
    }
    
    // Map 'text' to 'description' if older code uses it, or just update code
    var description: String { text }
}

struct RPGOption: Identifiable, Codable {
    var id: String { text }
    let text: String
    let scoreImpact: MindPentagon
    let outcomeText: String // Feedback
}

struct FactChecklistItem: Identifiable, Codable {
    let id: String
    let title: String
}

// MARK: - Daily Record
enum RecordType: String, Codable {
    case active // 主动实验 (High score)
    case passive // 被动觉察 (Medium score)
    case simulation // 情境模拟 (Low score)
    case factChecklist // 事实勾选
}

struct DailyRecord: Identifiable, Codable {
    let id: UUID
    let lawID: String
    let dayNumber: Int // 1, 2, 3
    let type: RecordType
    
    // Content
    let textContent: String // User's subjective report
    let factChecklistSelections: [String]?
    
    // For simulation mode, which option did they pick?
    let simulationOptionID: String?
    
    // The ID of the simulation scenario itself (e.g., "sim_law_social_001_d1_a")
    let simulationID: String?
    
    let scoreGained: MindPentagon
    let createdAt: Date
}

// MARK: - User Progress
struct UserProgress: Codable {
    var activeLawID: String?
    // Tracks progress for EACH law: [LawID: CurrentDay]
    // 0: Not started, 1: Day 1, ... 4: Completed
    var lawProgress: [String: Int]
    
    // Aggregate stats
    var totalStats: MindPentagon
    
    // Achievements (Unlocked Laws)
    // A law is unlocked when completed (3 days)
    var unlockedLawIDs: Set<String> = []
    
    // Onboarding Status
    var hasCompletedOnboarding: Bool = false
    
    // Tracks when a day was completed for a law.
    // Key: LawID, Value: Date (start of the day when completed)
    // Used to prevent advancing to the next day until the next calendar day.
    var lastCompletionDate: [String: Date] = [:]
}

// MARK: - User Profile (Firebase)
import FirebaseFirestore

struct UserProfile: Codable, Identifiable {
    @DocumentID var id: String?
    var email: String
    var createdAt: Date
    var isPro: Bool = false
    var lastActiveAt: Date?
    
    // Default initializer
    init(id: String? = nil, email: String, isPro: Bool = false) {
        self.id = id
        self.email = email
        self.createdAt = Date()
        self.isPro = isPro
        self.lastActiveAt = Date()
    }
}
