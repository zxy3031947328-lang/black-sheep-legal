import Foundation

// MARK: - Assessment Models (Onboarding / Daily Simulation)

struct Assessment: Codable {
    let id: String
    let questions: [AssessmentQuestion]
}

enum AssessmentScoringType: String, Codable {
    case linear
    case reverse
    case balanced
}

struct AssessmentQuestion: Identifiable, Codable {
    var id: String { text }
    let text: String // The question text
    let category: String // Which dimension this question measures (e.g. "objectivity")
    
    // Likert Scale (1-5)
    // 1: Strongly Disagree
    // 5: Strongly Agree
    let options: [AssessmentOption]
    
    // Legacy field kept for backward compatibility.
    // New files should prefer `scoringType`.
    let isPositive: Bool?
    let scoringType: AssessmentScoringType?
    
    enum CodingKeys: String, CodingKey {
        case text
        case category
        case options
        case isPositive
        case scoringType = "scoring_type"
    }
    
    var effectiveScoringType: AssessmentScoringType {
        if let scoringType {
            return scoringType
        }
        return (isPositive ?? true) ? .linear : .reverse
    }
}

struct AssessmentOption: Identifiable, Codable {
    var id: Int { value }
    let value: Int // 1-5
    let text: String // "Strongly Agree", etc.
}

// Result Calculation Helper
struct AssessmentResult: Codable {
    let totalStats: MindPentagon
    let dominantTrait: String // Which stat is highest
    let weakTrait: String // Which stat is lowest
}
