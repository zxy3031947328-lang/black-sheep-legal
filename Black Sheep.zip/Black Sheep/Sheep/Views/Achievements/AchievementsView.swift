import SwiftUI

// MARK: - Gothic Theme Colors (Shared)
// Colors are now defined in Sheep/Theme/ThemeManager.swift

struct AchievementsView: View {
    @ObservedObject var viewModel: AppViewModel
    @State private var selectedLaw: Law?
    @Environment(\.colorScheme) var colorScheme
    
    // Theme Accessor
    private var theme: AppTheme {
        switch viewModel.uiStyle {
        case .gothic: return GothicThemeImpl()
        case .minimalist: return MinimalistThemeImpl()
        }
    }
    
    // Corkboard layout: slightly larger spacing
    let columns = [
        GridItem(.flexible(), spacing: 20),
        GridItem(.flexible(), spacing: 20),
        GridItem(.flexible(), spacing: 20)
    ]
    
    var body: some View {
        ZStack {
            // Background is handled by MainTabView
            Color.clear
            
            VStack(alignment: .leading, spacing: 0) {
                // Category Selector (The "Small Scroll Wheel")
                CategorySelector(
                    selectedCategory: Binding(
                        get: { viewModel.currentCategory },
                        set: { viewModel.switchCategory($0) }
                    ),
                    theme: theme,
                    colorScheme: colorScheme
                )
                .zIndex(2) // Ensure it sits on top visually if needed
                
                // Header: Consistent with HomeView style (Optional, or integrated into selector)
                if theme.showSectionHeaders {
                    HStack {
                        Image(systemName: "archivebox.fill")
                            .font(.system(size: 18))
                            .foregroundColor(theme.style == .gothic ? Color.gothicCardPaper.opacity(0.8) : theme.textPrimary.opacity(0.78))
                        Text(theme.labelSectionDecrypted)
                            .font(.system(.title3, design: .monospaced))
                            .fontWeight(.bold)
                            .tracking(6)
                            .foregroundColor(theme.style == .gothic ? Color.gothicCardPaper.opacity(0.95) : theme.textPrimary.opacity(0.92))
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 20)
                    .padding(.bottom, 20)
                    .shadow(color: theme.cardShadow, radius: 4, x: 0, y: 2)
                    
                    Divider()
                        .background(theme.textSecondary.opacity(0.32))
                        .padding(.bottom, 20)
                } else {
                    Spacer().frame(height: 20)
                }
                
                ScrollView(showsIndicators: false) {
                    LazyVGrid(columns: columns, spacing: 24) {
                        ForEach(Array(viewModel.allLaws.enumerated()), id: \.element.id) { index, law in
                            let canAccess = viewModel.canAccessContent(category: viewModel.currentCategory, lawIndex: index)
                            let isUnlocked = canAccess || viewModel.isLawUnlocked(law.id)
                            
                            AchievementCard(
                                law: law,
                                isUnlocked: isUnlocked,
                                theme: theme,
                                colorScheme: colorScheme
                            )
                            .blur(radius: canAccess ? 0 : 3) // Blur if locked by paywall
                            .overlay(
                                Group {
                                    if !canAccess {
                                        Color.white.opacity(0.001) // Invisible hit target
                                            .onTapGesture {
                                                viewModel.showPaywall = true
                                            }
                                    }
                                }
                            )
                            .onTapGesture {
                                // Only allow opening if accessible
                                if canAccess {
                                    withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                                        selectedLaw = law
                                    }
                                } else {
                                    viewModel.showPaywall = true
                                }
                            }
                        }
                    }
                    .padding(24)
                    .padding(.bottom, 135) // Match lifted tab bar
                }
                .scrollContentBackground(.hidden) // Critical fix for iOS 16+ default background
                .background(Color.clear)
            }
            
            // Detail Overlay (Open File Folder)
            if let law = selectedLaw {
                Color.black.opacity(0.85)
                    .ignoresSafeArea()
                    .onTapGesture {
                        withAnimation { selectedLaw = nil }
                    }
                
                AchievementDetailOverlay(
                    law: law,
                    records: viewModel.localStore.dailyRecords.filter { $0.lawID == law.id && $0.type != .simulation },
                    theme: theme,
                    colorScheme: colorScheme,
                    onClose: { withAnimation { selectedLaw = nil } },
                    viewModel: viewModel
                )
                .transition(.scale(scale: 0.9).combined(with: .opacity))
                .zIndex(1) // Ensure it's on top
            }
        }
    }
}

struct AchievementCard: View {
    let law: Law
    let isUnlocked: Bool
    let theme: AppTheme
    let colorScheme: ColorScheme
    
    // Random rotation for pinned photo look (slightly right-leaning)
    @State private var rotation: Double = Double.random(in: 1...4)
    
    var body: some View {
        VStack(spacing: 8) {
            // Photo/File Frame
            ZStack {
                // Background Paper
                RoundedRectangle(cornerRadius: theme.cardCornerRadius)
                    .fill(
                        isUnlocked ? 
                        theme.cardBackground(isDark: colorScheme == .dark) :
                        AnyShapeStyle(theme.textTertiary.opacity(0.3)) // Locked state color
                    )
                    .aspectRatio(0.75, contentMode: .fit)
                    .overlay(
                        RoundedRectangle(cornerRadius: theme.cardCornerRadius)
                            .strokeBorder(
                                isUnlocked ? theme.cardBorder : theme.textTertiary.opacity(0.2),
                                lineWidth: 1
                            )
                    )
                    .shadow(color: theme.cardShadow, radius: 4, x: 2, y: 2)
                
                if isUnlocked {
                    VStack(spacing: 8) {
                        if theme.style == .gothic {
                            // Gothic: Eye + Stamp
                            // "Photo" placeholder
                            Rectangle()
                                .fill(theme.textPrimary.opacity(0.05))
                                .frame(height: 50)
                                .overlay(
                                    Image(systemName: "eye")
                                        .font(.title2)
                                        .foregroundColor(theme.textPrimary.opacity(0.5))
                                )
                                .padding(8)
                            
                            // Stamp
                            Text("VERIFIED")
                                .font(.system(size: 8, weight: .black, design: .monospaced))
                                .foregroundColor(theme.accent.opacity(0.7))
                                .padding(2)
                                .border(theme.accent.opacity(0.7), width: 1.5)
                                .rotationEffect(.degrees(-10))
                            
                            Spacer()
                        } else {
                            // Minimalist: Just Name (Chinese)
                            Spacer()
                            Text(law.displayChineseName)
                                .font(.system(.headline, design: theme.fontDesign))
                                .fontWeight(.bold)
                                .foregroundColor(theme.textPrimary)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 8)
                            Spacer()
                        }
                    }
                } else {
                    // Locked State: Low profile
                    VStack {
                        Image(systemName: "lock.fill")
                            .font(.title3)
                            .foregroundColor(theme.textTertiary)
                        Text("LOCKED")
                            .font(.system(size: 8, weight: .bold, design: .monospaced))
                            .foregroundColor(theme.textTertiary)
                            .padding(.top, 2)
                    }
                }
                
                // Pin (Visual decoration) - Gothic Only
                if theme.style == .gothic && theme.showEdgeBurn {
                    Circle()
                        .fill(Color.gothicAccentRed.opacity(0.8)) // Keep red pin for Gothic
                        .frame(width: 8, height: 8)
                        .shadow(color: .black.opacity(0.4), radius: 1, x: 1, y: 1)
                        .offset(y: -45) // Pin at top
                }
            }
            
            // Label
            Text(isUnlocked ? law.displayEnglishName : "Unknown")
                .font(.system(size: 10, weight: .medium, design: .default))
                .lineLimit(2)
                .multilineTextAlignment(.center)
                .minimumScaleFactor(0.85)
                .foregroundColor(isUnlocked ? theme.textSecondary : theme.textTertiary)
                .frame(maxWidth: .infinity, minHeight: 26, alignment: .top)
                .padding(.horizontal, 2)
        }
        .rotationEffect(.degrees(theme.style == .gothic ? rotation : 0))
        .opacity(isUnlocked ? 1.0 : 0.9)
    }
}

struct AchievementDetailOverlay: View {
    let law: Law
    let records: [DailyRecord]
    let theme: AppTheme
    let colorScheme: ColorScheme
    let onClose: () -> Void
    // Added ViewModel to support switching law
    var viewModel: AppViewModel? = nil
    
    // Random rotation for the opened file
    @State private var rotation: Double = Double.random(in: -1...1)
    
    var body: some View {
        ZStack {
            // Card Background with Texture (Copied from HomeView for consistency)
            RoundedRectangle(cornerRadius: theme.cardCornerRadius)
                .fill(theme.cardBackground(isDark: colorScheme == .dark))
                .overlay(
                    Group {
                        if theme.showGrain {
                            GothicNoiseOverlay(opacity: 0.1)
                        }
                    }
                )
                .overlay(
                     RoundedRectangle(cornerRadius: theme.cardCornerRadius)
                        .strokeBorder(theme.cardBorder, lineWidth: 1)
                )
                .shadow(color: theme.cardShadow, radius: 30)
            
            VStack(alignment: .leading, spacing: 0) {
                // Header: File Tab
                HStack {
                    Text("\(theme.labelNo)\(law.id.suffix(3).uppercased())")
                    .font(.system(.caption, design: .monospaced))
                    .foregroundColor(theme.textSecondary)
                    Spacer()
                    
                    // Switch Button
                    if let vm = viewModel, vm.currentLaw?.id != law.id {
                        Button(action: {
                            vm.startLaw(law)
                            onClose()
                        }) {
                            Text(theme.labelSwitchToLaw)
                                .font(.system(.caption, design: .monospaced))
                                .bold()
                                .foregroundColor(theme.accent)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(theme.accent.opacity(0.1))
                                .cornerRadius(4)
                        }
                        .padding(.trailing, 12)
                    }
                    
                    Button(action: onClose) {
                        Image(systemName: "xmark")
                            .foregroundColor(theme.textPrimary)
                            .font(.title3)
                    }
                }
                .padding(20)
                .background(theme.textPrimary.opacity(0.05))
                
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 24) {
                        
                        // Title
                        Text(law.name)
                            .font(.system(.title, design: theme.fontDesign))
                            .bold()
                            .foregroundColor(theme.textPrimary)
                            .padding(.top, 10)
                        
                        // Source Info
                        if let source = law.source {
                            HStack(spacing: 6) {
                                if let year = source.originYear {
                                    Text(String(year))
                                        .font(.system(.caption, design: .monospaced))
                                        .bold()
                                        .foregroundColor(theme.accent)
                                }
                                if source.originYear != nil && source.researcher != nil {
                                    Text("·")
                                        .font(.caption)
                                        .foregroundColor(theme.textSecondary)
                                }
                                if let researcher = source.researcher {
                                    Text(researcher)
                                        .font(.system(.caption, design: .monospaced))
                                        .foregroundColor(theme.textSecondary)
                                }
                            }
                            .padding(.bottom, 4)
                        }
                        
                        Divider().background(theme.textPrimary)
                        
                        // Section 1: Theory
                        VStack(alignment: .leading, spacing: 8) {
                            Text(theme.labelSectionPrinciple)
                                .font(.system(.subheadline, design: .monospaced))
                                .bold()
                                .foregroundColor(theme.accent)
                            
                            // Prefer deep dive interpretation if available, otherwise basic detail text
                            if let deepDive = law.deepDive {
                                Text(deepDive.detailedInterpretation)
                                    .font(.system(.body, design: theme.fontDesign))
                                    .foregroundColor(theme.textPrimary)
                                    .lineSpacing(6)
                            } else {
                                Text(law.detailText)
                                    .font(.system(.body, design: theme.fontDesign))
                                    .foregroundColor(theme.textPrimary)
                                    .lineSpacing(6)
                            }
                        }
                        
                        Divider().background(theme.textPrimary.opacity(0.3))
                        
                        // Section 2: Field Notes (Records)
                        VStack(alignment: .leading, spacing: 12) {
                            Text(theme.labelSectionNotes)
                                .font(.system(.subheadline, design: .monospaced))
                                .bold()
                                .foregroundColor(theme.accent)
                            
                            if !records.isEmpty {
                                ForEach(records) { record in
                                    VStack(alignment: .leading, spacing: 6) {
                                        Text(record.createdAt.formatted(date: .numeric, time: .omitted))
                                            .font(.system(size: 10, design: .monospaced))
                                            .foregroundColor(theme.textSecondary)
                                        
                                        Text(record.textContent)
                                            .font(.system(.callout, design: theme.fontDesign)) // Handwritten feel
                                            .italic()
                                            .foregroundColor(theme.textPrimary)
                                            .lineSpacing(4)
                                    }
                                    .padding(12)
                                    .background(Color.white.opacity(0.3)) // Lighter patch - keeping for now
                                    .cornerRadius(4)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 4)
                                            .stroke(theme.textPrimary.opacity(0.1), lineWidth: 1)
                                    )
                                }
                            } else {
                                Text(theme.labelNoRecords)
                                    .font(.system(.caption, design: .monospaced))
                                    .italic()
                                    .foregroundColor(theme.textSecondary)
                            }
                        }
                    }
                    .padding(24)
                }
            }
        }
        .frame(maxWidth: 340, maxHeight: 550)
        .rotationEffect(.degrees(theme.style == .gothic ? rotation : 0))
    }
}

// MARK: - Category Selector (Small Scroll Wheel)
struct CategorySelector: View {
    @Binding var selectedCategory: LawCategory
    let theme: AppTheme
    let colorScheme: ColorScheme
    
    var body: some View {
        ZStack {
            // Background Panel
            if theme.style == .gothic {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.black.opacity(0.6))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .strokeBorder(theme.accent.opacity(0.3), lineWidth: 1)
                    )
                    .shadow(color: theme.cardShadow, radius: 4)
            } else {
                RoundedRectangle(cornerRadius: 12)
                    .fill(theme.cardBackground(isDark: colorScheme == .dark).opacity(0.5))
            }
            
            HStack {
                // Label (Vertical Text)
                Text("SECTION")
                    .font(.system(size: 10, design: .monospaced))
                    .fontWeight(.bold)
                    .foregroundColor(theme.accent)
                    .rotationEffect(.degrees(-90))
                    .fixedSize()
                    .frame(width: 20)
                
                // The Wheel
                Picker("Category", selection: $selectedCategory) {
                    ForEach(LawCategory.allCases, id: \.self) { category in
                        Text(category.displayName)
                            .font(.system(.subheadline, design: theme.fontDesign))
                            .fontWeight(.medium)
                            .foregroundColor(theme.style == .gothic ? Color.gothicCardPaper : theme.textPrimary)
                            .tag(category)
                    }
                }
                .pickerStyle(.wheel)
                .frame(height: 100)
                .clipped()
                .background(Color.clear) // Ensure wheel background is clear
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
        }
        .frame(height: 120)
        .padding(.horizontal, 24)
        .padding(.top, 10) // Small top padding
    }
}
