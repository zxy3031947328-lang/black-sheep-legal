import SwiftUI

struct SplashView: View {
    // Callback when animation finishes
    var onFinish: () -> Void
    
    // Animation States
    @State private var logoOpacity: Double = 0
    @State private var logoScale: Double = 0.95
    
    var body: some View {
        ZStack {
            // 1. Pure White Background
            Color.white.ignoresSafeArea()
            
            // 2. The Logo Image
            Image("AppLogo") // Ensure this name matches your Asset
                .resizable()
                .scaledToFit()
                .frame(width: 140, height: 140) // 0.5x size
                .opacity(logoOpacity)
                .scaleEffect(logoScale)
                // Fallback if image not found
                .overlay(
                    Group {
                        if UIImage(named: "AppLogo") == nil {
                            Image(systemName: "cube.fill") // Fallback Icon
                                .resizable()
                                .scaledToFit()
                                .foregroundColor(.black)
                                .opacity(0.1)
                        }
                    }
                )
        }
        .onAppear {
            startAnimation()
        }
    }
    
    private func startAnimation() {
        // Reset
        logoOpacity = 0
        logoScale = 0.95
        
        // 1. Fade In & Scale Up (0s - 0.8s)
        withAnimation(.easeInOut(duration: 0.8)) {
            logoOpacity = 1
            logoScale = 1.05
        }
        
        // 2. Hold (0.8s - 2.0s) -> Then Trigger Finish
        // Stay visible for 1.2 seconds (Total 2.0s)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            // 3. Trigger Finish
            // We notify the parent (SheepApp) to start the fade-out transition
            onFinish()
        }
    }
}

// Preview
struct SplashView_Previews: PreviewProvider {
    static var previews: some View {
        SplashView(onFinish: {})
    }
}
