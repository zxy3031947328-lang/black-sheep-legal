import SwiftUI

enum AppLegal {
    static let standardEULAURL = URL(string: "https://www.apple.com/legal/internet-services/itunes/dev/stdeula/")!
}

struct LegalLinksRow: View {
    let textColor: Color
    let secondaryColor: Color
    @State private var showingPrivacyPolicy = false

    var body: some View {
        HStack(spacing: 8) {
            Button("隐私政策") {
                showingPrivacyPolicy = true
            }
            .buttonStyle(.plain)
            .underline()
            .foregroundColor(textColor)

            Text("|")
                .foregroundColor(secondaryColor)

            Link("使用条款", destination: AppLegal.standardEULAURL)
                .underline()
                .foregroundColor(textColor)
        }
        .font(.system(size: 12))
        .sheet(isPresented: $showingPrivacyPolicy) {
            LegalDocumentView()
        }
    }
}

struct LegalDocumentView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationView {
            ScrollView {
                Text(
"""
Black Sheep 隐私政策

我们仅在提供核心功能所必需的范围内处理你的数据：

1. 账号信息
当你注册或登录时，应用会通过 Firebase Authentication 处理你的邮箱地址与密码凭据，用于身份验证与账号安全。

2. 使用内容
你的昵称、头像、学习进度、每日记录与相关成长档案会存储在设备本地；当你登录账号并启用同步后，这些内容会同步到你的云端账户，用于跨设备恢复与备份。

3. 订阅与购买
应用通过 Apple 的 StoreKit 框架处理订阅、终身买断、恢复购买及会员状态校验。开发者不会直接获取你的完整支付信息。

4. 必要权限
如果你主动选择上传头像，应用会请求访问系统照片库。未授权时，不会读取你的照片内容。

5. 数据用途
以上信息仅用于账号登录、进度同步、内容解锁、购买验证与功能展示，不用于第三方广告投放。

6. 数据控制
你可以随时在应用内修改昵称、头像，或在账号设置中删除账号与云端数据。删除账号不会自动取消 Apple 订阅，订阅管理需通过 Apple 账户完成。

7. 条款说明
订阅与购买同时受 Apple 标准最终用户许可协议（EULA）约束。你可以在“使用条款”链接中查看完整内容。
"""
                )
                .font(.system(.body, design: .default))
                .foregroundColor(.primary)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(20)
            }
            .navigationTitle("隐私政策")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成") {
                        dismiss()
                    }
                }
            }
        }
    }
}
