import SwiftUI
import FirebaseAuth

struct LoginView: View {
    let uiStyle: UIStyle

    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) var colorScheme
    @StateObject private var authService = AuthService.shared
    
    // UI State
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var isRegistering = false // Toggle between Login and Register
    @State private var isLoading = false
    @State private var errorMessage: String?
    
    // Animation
    @Namespace private var animation

    private var theme: AppTheme {
        switch uiStyle {
        case .gothic: return GothicThemeImpl()
        case .minimalist: return MinimalistThemeImpl()
        }
    }
    
    var body: some View {
        ZStack {
            // Background
            theme.backgroundMain.ignoresSafeArea()
            
            VStack(spacing: 30) {
                // Header
                Text(isRegistering ? "加入黑羊计划" : "身份验证")
                    .font(.system(size: 28, weight: .bold, design: .serif))
                    .foregroundColor(theme.textPrimary)
                    .padding(.top, 40)
                
                // Form
                VStack(spacing: 20) {
                    // Email Field
                    CustomTextField(
                        icon: "envelope",
                        placeholder: "邮箱",
                        text: $email,
                        theme: theme,
                        isDark: colorScheme == .dark
                    )
                        .textContentType(.emailAddress)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                    
                    // Password Field
                    CustomSecureField(
                        icon: "lock",
                        placeholder: "密码",
                        text: $password,
                        theme: theme,
                        isDark: colorScheme == .dark
                    )
                        .textContentType(isRegistering ? .newPassword : .password)
                    
                    if isRegistering {
                        CustomSecureField(
                            icon: "lock.shield",
                            placeholder: "确认密码",
                            text: $confirmPassword,
                            theme: theme,
                            isDark: colorScheme == .dark
                        )
                            .textContentType(.newPassword)
                            .transition(.opacity.combined(with: .move(edge: .top)))
                    }
                }
                .padding(.horizontal, 30)
                
                // Error Message
                if let error = errorMessage {
                    Text(error)
                        .font(.caption)
                        .foregroundColor(.red)
                        .padding(.horizontal, 30)
                        .multilineTextAlignment(.center)
                        .transition(.opacity)
                }
                
                // Action Button
                Button(action: performAction) {
                    if isLoading {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                    } else {
                        Text(isRegistering ? "注册账号" : "登 录")
                            .font(.system(size: 16, weight: .bold))
                            .tracking(2)
                            .foregroundColor(theme.style == .minimalist ? theme.backgroundMain : .white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(theme.accent)
                            .cornerRadius(12)
                            .shadow(color: theme.accent.opacity(0.3), radius: 8, x: 0, y: 4)
                    }
                }
                .disabled(isLoading)
                .padding(.horizontal, 30)
                .padding(.top, 10)
                
                // Toggle Mode
                Button(action: {
                    withAnimation(.spring()) {
                        isRegistering.toggle()
                        errorMessage = nil
                    }
                }) {
                    HStack(spacing: 4) {
                        Text(isRegistering ? "已有账号？" : "还没有账号？")
                            .foregroundColor(theme.textTertiary)
                        Text(isRegistering ? "去登录" : "去注册")
                            .fontWeight(.bold)
                            .foregroundColor(theme.accent)
                    }
                    .font(.footnote)
                }

                VStack(spacing: 8) {
                    Text("继续即表示你同意相关使用条款，并了解账号与同步数据的处理方式。")
                        .font(.system(size: 11))
                        .foregroundColor(theme.textTertiary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 32)

                    LegalLinksRow(
                        textColor: theme.accent,
                        secondaryColor: theme.textTertiary.opacity(0.45)
                    )
                }
                
                Spacer()
            }
            
            // Close Button
            VStack {
                HStack {
                    Spacer()
                    Button(action: { presentationMode.wrappedValue.dismiss() }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 30))
                            .foregroundColor(theme.textTertiary.opacity(0.5))
                            .padding()
                    }
                }
                Spacer()
            }
        }
        .onTapGesture {
            hideKeyboard()
        }
    }
    
    // MARK: - Logic
    
    func performAction() {
        hideKeyboard()
        errorMessage = nil
        
        let normalizedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        email = normalizedEmail
        
        // Basic Validation
        guard !normalizedEmail.isEmpty, !password.isEmpty else {
            errorMessage = "请输入邮箱和密码"
            return
        }
        
        guard normalizedEmail.contains("@") else {
            errorMessage = "请输入有效邮箱"
            return
        }
        
        if isRegistering && password.count < 6 {
            errorMessage = "密码至少需要 6 位"
            return
        }
        
        if isRegistering && password != confirmPassword {
            errorMessage = "两次输入的密码不一致"
            return
        }
        
        isLoading = true
        
        Task {
            do {
                if isRegistering {
                    try await authService.signUp(email: normalizedEmail, password: password)
                } else {
                    try await authService.signIn(email: normalizedEmail, password: password)
                }
                // Success: Close view
                await MainActor.run {
                    isLoading = false
                    presentationMode.wrappedValue.dismiss()
                }
            } catch {
                await MainActor.run {
                    isLoading = false
                    errorMessage = error.localizedDescription
                }
            }
        }
    }
    
    private func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

// MARK: - Custom Components

struct CustomTextField: View {
    let icon: String
    let placeholder: String
    @Binding var text: String
    let theme: AppTheme
    let isDark: Bool
    
    var body: some View {
        HStack(spacing: 15) {
            Image(systemName: icon)
                .foregroundColor(theme.textTertiary)
                .frame(width: 20)
            
            TextField(placeholder, text: $text)
                .foregroundColor(theme.textPrimary)
        }
        .padding()
        .background(theme.cardBackground(isDark: isDark))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(theme.textTertiary.opacity(0.1), lineWidth: 1)
        )
    }
}

struct CustomSecureField: View {
    let icon: String
    let placeholder: String
    @Binding var text: String
    let theme: AppTheme
    let isDark: Bool
    
    var body: some View {
        HStack(spacing: 15) {
            Image(systemName: icon)
                .foregroundColor(theme.textTertiary)
                .frame(width: 20)
            
            SecureField(placeholder, text: $text)
                .foregroundColor(theme.textPrimary)
        }
        .padding()
        .background(theme.cardBackground(isDark: isDark))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(theme.textTertiary.opacity(0.1), lineWidth: 1)
        )
    }
}
