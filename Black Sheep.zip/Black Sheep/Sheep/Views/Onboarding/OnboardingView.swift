import SwiftUI

struct OnboardingView: View {
    @ObservedObject var viewModel: AppViewModel
    
    // Flow State
    @State private var step: OnboardingStep = .intro
    @State private var answers: [String: Int] = [:] // QuestionID : Score
    @State private var assessmentQuestions: [AssessmentQuestion] = AssessmentService.shared.assessment?.questions ?? []
    
    @Environment(\.colorScheme) var colorScheme
    
    // Theme Accessor (Reused logic)
    private var theme: AppTheme {
        switch viewModel.uiStyle {
        case .gothic: return GothicThemeImpl()
        case .minimalist: return MinimalistThemeImpl()
        }
    }
    
    enum OnboardingStep {
        case intro
        case assessment
        case result
    }
    
    var body: some View {
        ZStack {
            // Background
            GlobalBackgroundView(style: viewModel.uiStyle, theme: theme)
            
            switch step {
            case .intro:
                IntroView(theme: theme, onNext: { withAnimation { step = .assessment } })
                
            case .assessment:
                AssessmentFlowView(
                    theme: theme,
                    colorScheme: colorScheme,
                    questions: assessmentQuestions,
                    onComplete: { finalAnswers in
                        self.answers = finalAnswers
                        withAnimation { step = .result }
                    }
                )
                
            case .result:
                ResultView(
                    answers: answers,
                    theme: theme,
                    onFinish: { stats in
                        viewModel.completeOnboarding(initialStats: stats)
                    }
                )
            }
        }
        .onAppear {
            assessmentQuestions = AssessmentService.shared.assessment?.questions ?? []
        }
    }
}

// Subviews

struct IntroView: View {
    let theme: AppTheme
    let onNext: () -> Void
    
    var body: some View {
        VStack(spacing: 40) {
            Spacer()
            
            Image(systemName: "eye.fill")
                .font(.system(size: 80))
                .foregroundColor(theme.accent)
                .shadow(color: theme.accent.opacity(0.5), radius: 10)
            
            Text("欢迎来到 Sheep")
                .font(.system(size: 34, weight: .bold, design: theme.fontDesign))
                .foregroundColor(theme.textPrimary)
            
            Text("这是一个关于自我觉察与人性实验的旅程。\n在开始之前，我们需要了解你的现状。")
                .font(.system(.body, design: theme.fontDesign))
                .multilineTextAlignment(.center)
                .foregroundColor(theme.textSecondary)
                .padding(.horizontal)
                .lineSpacing(6)
            
            Spacer()
            
            Button(action: onNext) {
                Text("开始测试")
                    .font(.system(.headline, design: .monospaced))
                    .foregroundColor(theme.backgroundMain)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(theme.accent)
                    .cornerRadius(4)
            }
            .padding(.horizontal, 40)
            .padding(.bottom, 60)
        }
    }
}

struct AssessmentFlowView: View {
    let theme: AppTheme
    let colorScheme: ColorScheme
    let questions: [AssessmentQuestion]
    let onComplete: ([String: Int]) -> Void
    
    @State private var currentQuestionIndex: Int = 0
    @State private var answers: [String: Int] = [:]
    
    var body: some View {
        if questions.isEmpty {
            VStack(spacing: 16) {
                Spacer()
                Text("题库加载失败，请重启应用后重试")
                    .font(.system(.body, design: .monospaced))
                    .foregroundColor(theme.textSecondary)
                Spacer()
            }
        } else {
        VStack {
            let question = questions[currentQuestionIndex]
            
            // Progress Bar
            ProgressView(value: Double(currentQuestionIndex + 1), total: Double(questions.count))
                .tint(theme.accent)
                .padding()
            
            Spacer()
            
            // Question
            Text(question.text)
                .font(.system(.title3, design: theme.fontDesign))
                .bold()
                .multilineTextAlignment(.center)
                .foregroundColor(theme.style == .gothic ? Color.gothicCardPaper.opacity(0.95) : theme.textPrimary)
                .shadow(color: theme.style == .gothic ? Color.black.opacity(0.45) : .clear, radius: 1, x: 0, y: 1)
                .padding()
            
            Spacer()
            
            // Options
            VStack(spacing: 16) {
                ForEach(question.options) { option in
                    Button(action: {
                        selectAnswer(questionID: question.id, value: option.value)
                    }) {
                        Text(option.text)
                            .font(.system(.body, design: theme.fontDesign))
                            .foregroundColor(theme.textPrimary)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(theme.cardBackground(isDark: colorScheme == .dark))
                            .overlay(
                                RoundedRectangle(cornerRadius: theme.cardCornerRadius)
                                    .strokeBorder(theme.cardBorder, lineWidth: 1)
                            )
                            .cornerRadius(theme.cardCornerRadius)
                            .shadow(color: theme.cardShadow, radius: 2, y: 1)
                    }
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 40)
        }
        }
    }
    
    func selectAnswer(questionID: String, value: Int) {
        var newAnswers = answers
        newAnswers[questionID] = value
        answers = newAnswers
        
        if currentQuestionIndex < questions.count - 1 {
            withAnimation {
                currentQuestionIndex += 1
            }
        } else {
            onComplete(answers)
        }
    }
}

struct ResultView: View {
    let answers: [String: Int]
    let theme: AppTheme
    let onFinish: (MindPentagon) -> Void
    
    var stats: MindPentagon {
        AssessmentService.shared.calculateScore(answers: answers)
    }
    
    var body: some View {
        VStack(spacing: 30) {
            Spacer()
            
            Text("初始画像生成完毕")
                .font(.system(.title2, design: theme.fontDesign))
                .foregroundColor(theme.textPrimary)
            
            MindPentagonView(stats: stats, size: 250)
                .frame(height: 250)
            
            Text("这是你当前的心理模型。\n随着实验的进行，它将不断变化。")
                .font(.system(.caption, design: .monospaced))
                .foregroundColor(theme.textSecondary)
                .multilineTextAlignment(.center)
                .padding()
                .lineSpacing(4)
            
            Button(action: { onFinish(stats) }) {
                Text("进入实验")
                    .font(.system(.headline, design: .monospaced))
                    .foregroundColor(theme.backgroundMain) // Text on accent
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(theme.accent)
                    .cornerRadius(4)
            }
            .padding(.horizontal, 40)
            
            Spacer()
        }
    }
}
