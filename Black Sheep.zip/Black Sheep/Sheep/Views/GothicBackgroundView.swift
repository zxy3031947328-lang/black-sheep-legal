import SwiftUI

/// Shared aged-paper desk background used across core screens.
struct GothicBackgroundView: View {
    var body: some View {
        ZStack {
            // Opaque base to prevent any system tint bleed-through.
            Color.black.ignoresSafeArea()

            RadialGradient(
                gradient: Gradient(colors: [.gothicBackgroundStart, .gothicBackgroundEnd]),
                center: .center,
                startRadius: 20,
                endRadius: 600
            )
            .ignoresSafeArea()
            .overlay(
                GeometryReader { _ in
                    Canvas { context, size in
                        for _ in 0..<300 {
                            let x = Double.random(in: 0...size.width)
                            let y = Double.random(in: 0...size.height)
                            let opacity = Double.random(in: 0.03...0.1)
                            context.fill(
                                Path(CGRect(x: x, y: y, width: 2, height: 2)),
                                with: .color(.white.opacity(opacity))
                            )
                        }
                    }
                }
                .ignoresSafeArea()
            )
        }
    }
}
