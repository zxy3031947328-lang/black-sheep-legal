import SwiftUI

struct MainTabView: View {
    @ObservedObject var viewModel: AppViewModel
    
    // Tab State
    @State private var selectedTab = 1 // Start at Home (1)
    
    // Theme Accessor
    private var theme: AppTheme {
        switch viewModel.uiStyle {
        case .gothic: return GothicThemeImpl()
        case .minimalist: return MinimalistThemeImpl()
        }
    }
    
    var body: some View {
        ZStack(alignment: .bottom) {
            // 1. Shared Global Background (Dynamic)
            GlobalBackgroundView(style: viewModel.uiStyle, theme: theme)
            
            // 2. Content: Native TabView with Page Style (Enables Swipe)
            TabView(selection: $selectedTab) {
                AchievementsView(viewModel: viewModel)
                    .tag(0)
                    .background(Color.clear) // Crucial for transparency
                
                HomeView(viewModel: viewModel)
                    .tag(1)
                    .background(Color.clear)
                
                MeView(viewModel: viewModel)
                    .tag(2)
                    .background(Color.clear)
            }
            .tabViewStyle(.page(indexDisplayMode: .never)) // Hides dots, enables swipe
            .ignoresSafeArea()
            
            // 3. Custom Tab Bar (Floating)
            CustomTabBar(
                selectedTab: $selectedTab,
                theme: theme,
                viewModel: viewModel // Pass viewModel
            )
        }
        .ignoresSafeArea(.keyboard)
        // We handle bottom padding in child views to accommodate the floating bar
        .fullScreenCover(isPresented: $viewModel.showOnboarding) {
            OnboardingView(viewModel: viewModel)
        }
        .sheet(isPresented: $viewModel.showPaywall) {
            PaywallView()
        }
    }
}

// MARK: - Global Background
struct GlobalBackgroundView: View {
    let style: UIStyle
    let theme: AppTheme
    
    var body: some View {
        ZStack {
            if style == .gothic {
                // Gothic Vintage: Radial Gradient + Noise
                RadialGradient(
                    gradient: Gradient(colors: [theme.backgroundMain, .black]), // Hardcoded black end for depth
                    center: .center,
                    startRadius: 2,
                    endRadius: 600
                )
                .ignoresSafeArea()
                
                GothicNoiseOverlay(opacity: 0.05)
            } else {
                // Minimalist: Pure Flat Color (Adapts to Light/Dark)
                theme.backgroundMain
                    .ignoresSafeArea()
            }
        }
    }
}

// MARK: - Custom Tab Bar
struct CustomTabBar: View {
    @Binding var selectedTab: Int
    let theme: AppTheme
    @ObservedObject var viewModel: AppViewModel // Receive viewModel
    
    var body: some View {
        HStack(spacing: 0) {
            // Archives
            TabBarItem(
                iconName: "archivebox",
                selectedIcon: "archivebox.fill",
                title: "档案",
                isSelected: selectedTab == 0,
                theme: theme
            ) { 
                withAnimation { selectedTab = 0 } 
            }
            
            Spacer()
            
            // Home / Experiment
            TabBarItem(
                iconName: "eye",
                selectedIcon: "eye.fill",
                title: "观测",
                isSelected: selectedTab == 1,
                theme: theme
            ) { withAnimation { selectedTab = 1 } }
            
            Spacer()
            
            // Me / ID
            TabBarItem(
                iconName: "person.crop.rectangle",
                selectedIcon: "person.crop.rectangle.fill",
                title: "证件",
                isSelected: selectedTab == 2,
                theme: theme
            ) { withAnimation { selectedTab = 2 } }
        }
        .padding(.horizontal, 40)
        .padding(.top, 12)
        .padding(.bottom, 30) // Lift tab bar content
        .background(
            ZStack(alignment: .top) {
                // Background Layer
                if theme.style == .gothic {
                    // Gothic: Complex layered background
                    Color.gothicBackgroundStart.opacity(0.98)
                    GothicNoiseOverlay(opacity: 0.05)
                    
                    // Top Border (Gold/Paper line)
                    VStack {
                        Rectangle()
                            .fill(Color.gothicCardPaper.opacity(0.2))
                            .frame(height: 1)
                        Spacer()
                    }
                } else {
                    // Minimalist: Clean Blur or Solid
                    // Use a visual effect view for blur if possible, or solid for now
                    theme.backgroundMain.opacity(0.98)
                    .shadow(color: theme.cardShadow, radius: 10, y: -5)
                }
            }
            .frame(maxHeight: .infinity) // Fill available height
            .padding(.bottom, -100) // Extend way below safe area
            .ignoresSafeArea()
        )
        .offset(y: -15)
    }
}

struct TabBarItem: View {
    let iconName: String
    let selectedIcon: String
    let title: String
    let isSelected: Bool
    let theme: AppTheme
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 6) {
                Image(systemName: isSelected ? selectedIcon : iconName)
                    .font(.system(size: 20))
                    // Subtle glow for selected only in Gothic
                    .shadow(color: (isSelected && theme.showInnerGlow) ? theme.textPrimary.opacity(0.5) : .clear, radius: 4)
                
                Text(title)
                    .font(.system(size: 10, design: .monospaced)) // Monospaced kept for consistency
                    .fontWeight(isSelected ? .bold : .regular)
                    .tracking(1)
            }
            // Dynamic Color Logic
            .foregroundColor(
                isSelected ? theme.accent : theme.textTertiary
            )
            .frame(maxWidth: .infinity)
            .contentShape(Rectangle())
        }
    }
}

// Helper for noise (Kept as is)
struct GothicNoiseOverlay: View {
    var opacity: Double = 0.05
    
    var body: some View {
        GeometryReader { proxy in
            Canvas { context, size in
                let w = size.width
                let h = size.height
                // Simple random noise
                for _ in 0..<2000 {
                    let x = Double.random(in: 0...w)
                    let y = Double.random(in: 0...h)
                    let length = Double.random(in: 1...2)
                    context.fill(
                        Path(CGRect(x: x, y: y, width: length, height: length)),
                        with: .color(.white.opacity(Double.random(in: 0...opacity)))
                    )
                }
            }
        }
        .allowsHitTesting(false)
        .ignoresSafeArea()
    }
}
