import SwiftUI
import StoreKit

struct PaywallView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var storeManager = StoreManager.shared
    @Environment(\.colorScheme) var colorScheme
    
    // Theme for Paywall (Always use a mix of Gothic/Minimalist to show what they get)
    private var bgColor: Color {
        Color.black
    }

    private var statusMessage: String? {
        storeManager.transactionMsg.isEmpty ? nil : storeManager.transactionMsg
    }
    
    var body: some View {
        ZStack {
            // Background: Dark Gothic Vibe
            bgColor.ignoresSafeArea()
            
            // Noise Overlay
            Image(systemName: "noise") // Fallback if no noise asset, or use code
                .opacity(0.05)
            
            VStack(spacing: 0) {
                // Header
                HStack {
                    Spacer()
                    Button(action: { presentationMode.wrappedValue.dismiss() }) {
                        Image(systemName: "xmark")
                            .foregroundColor(.white.opacity(0.6))
                            .font(.title3)
                            .padding()
                    }
                }
                
                ScrollView {
                    VStack(spacing: 30) {
                        // Title
                        VStack(spacing: 10) {
                            Image(systemName: "lock.open.trianglebadge.exclamationmark.fill")
                                .font(.system(size: 60))
                                .foregroundColor(.white)
                                .shadow(color: .white.opacity(0.5), radius: 10)
                            
                            Text("UNLOCK THE INNER WORLD")
                                .font(.system(.title2, design: .monospaced))
                                .fontWeight(.black)
                                .foregroundColor(.white)
                                .tracking(2)
                            
                            Text("解锁黑羊完整版")
                                .font(.system(.body, design: .serif))
                                .foregroundColor(.white.opacity(0.8))
                        }
                        .padding(.top, 20)
                        
                        // Features List
                        VStack(alignment: .leading, spacing: 24) {
                            FeatureRow(icon: "eye.fill", title: "解锁哥特模式", desc: "切换至深渊视角的沉浸式体验")
                            FeatureRow(icon: "brain.head.profile", title: "全心理法则", desc: "金钱、权力、情感等8大板块")
                            FeatureRow(icon: "infinity", title: "无限档案", desc: "永久保存你的每一次抉择与觉察")
                            FeatureRow(icon: "app.badge.fill", title: "支持独立开发", desc: "持续更新，无广告干扰")
                        }
                        .padding(.horizontal, 30)
                        .padding(.vertical, 20)
                        
                        Spacer(minLength: 20)
                        
                        // Products List
                        switch storeManager.productsLoadState {
                        case .idle, .loading:
                            VStack(spacing: 20) {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                Text("正在连接 App Store...")
                                    .font(.caption)
                                    .foregroundColor(.white.opacity(0.6))
                            }
                            .frame(height: 200)
                        case .failed(let message):
                            VStack(spacing: 14) {
                                Image(systemName: "wifi.exclamationmark")
                                    .font(.title2)
                                    .foregroundColor(.white.opacity(0.9))
                                Text(message)
                                    .font(.caption)
                                    .foregroundColor(.white.opacity(0.7))
                                    .multilineTextAlignment(.center)
                                    .padding(.horizontal, 28)
                                Button {
                                    Task { await storeManager.loadProducts(force: true) }
                                } label: {
                                    Text("重试连接")
                                        .font(.caption)
                                        .foregroundColor(.black)
                                        .padding(.horizontal, 18)
                                        .padding(.vertical, 10)
                                        .background(Color.white)
                                        .cornerRadius(10)
                                }
                            }
                            .frame(height: 200)
                        case .loaded:
                            VStack(spacing: 12) {
                                // Yearly (Best Value)
                                if let yearly = storeManager.products.first(where: { $0.id.contains("yearly") }) {
                                    ProductButton(product: yearly, isBestValue: true) {
                                        Task { await storeManager.purchase(yearly) }
                                    }
                                }
                                
                                // Monthly
                                if let monthly = storeManager.products.first(where: { $0.id.contains("monthly") }) {
                                    ProductButton(product: monthly, isBestValue: false) {
                                        Task { await storeManager.purchase(monthly) }
                                    }
                                }
                                
                                // Lifetime (Subtle)
                                if let lifetime = storeManager.products.first(where: { $0.id.contains("lifetime") }) {
                                    Button(action: {
                                        Task { await storeManager.purchase(lifetime) }
                                    }) {
                                        Text("或者 \(lifetime.displayPrice) 终身买断")
                                            .font(.caption)
                                            .underline()
                                            .foregroundColor(.white.opacity(0.5))
                                            .padding(.top, 8)
                                    }
                                }
                            }
                            .padding(.horizontal, 20)
                        }

                        if let statusMessage {
                            Text(statusMessage)
                                .font(.caption)
                                .foregroundColor(.white.opacity(0.7))
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 28)
                        }
                        
                        // Restore
                        Button(action: {
                            Task { await storeManager.restorePurchases() }
                        }) {
                            Text("恢复购买")
                                .font(.caption)
                                .foregroundColor(.white.opacity(0.6))
                        }
                        .padding(.top, 10)
                        
                        // Footer Info (Legal)
                        VStack(spacing: 6) {
                            Text("月度与年度订阅会自动续期，除非你在当前周期结束前至少 24 小时关闭自动续费。")
                            Text("终身版为一次性买断，不会自动续费。")
                            LegalLinksRow(
                                textColor: .white.opacity(0.72),
                                secondaryColor: .white.opacity(0.3)
                            )
                        }
                        .font(.system(size: 10))
                        .foregroundColor(.white.opacity(0.3))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 40)
                        .padding(.bottom, 40)
                        .padding(.top, 20)
                    }
                }
            }
            
            // Loading Overlay
            if storeManager.purchaseState == .purchasing {
                Color.black.opacity(0.6).ignoresSafeArea()
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
            }
        }
        .onChange(of: storeManager.purchaseState) { _, state in
            if state == .success || state == .restored {
                presentationMode.wrappedValue.dismiss()
            }
        }
        .task {
            await storeManager.loadProducts(force: storeManager.products.isEmpty)
        }
    }
}

struct FeatureRow: View {
    let icon: String
    let title: String
    let desc: String
    
    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundColor(.white)
                .frame(width: 24)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.white)
                
                Text(desc)
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.6))
                    .lineLimit(2)
            }
        }
    }
}

struct ProductButton: View {
    let product: Product
    let isBestValue: Bool
    let action: () -> Void

    private var subtitle: String? {
        if isBestValue {
            return "推荐选择"
        }

        if let subscriptionPeriod = product.subscription?.subscriptionPeriod {
            return subscriptionPeriod.unit == .year ? "年度自动续订" : "月度自动续订"
        }

        return "永久解锁"
    }
    
    var body: some View {
        Button(action: action) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(product.displayName)
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                    
                    if let subtitle {
                        Text(subtitle)
                            .font(.caption)
                            .foregroundColor(.black.opacity(0.7))
                    }
                }
                
                Spacer()
                
                VStack(alignment: .trailing) {
                    Text(product.displayPrice)
                        .font(.title3)
                        .fontWeight(.heavy)
                        .foregroundColor(.black)
                    
                    if let subscriptionPeriod = product.subscription?.subscriptionPeriod {
                        Text("/ \(subscriptionPeriod.unit == .year ? "年" : "月")")
                            .font(.caption)
                            .foregroundColor(.black.opacity(0.6))
                    }
                }
            }
            .padding()
            .background(Color.white)
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(isBestValue ? Color.yellow : Color.clear, lineWidth: isBestValue ? 2 : 0)
            )
            .shadow(color: .white.opacity(0.1), radius: 5)
        }
    }
}

// MOCK COMPONENT FOR PREVIEW
struct MockProductButton: View {
    let title: String
    let price: String
    let period: String
    let isBestValue: Bool
    let trialText: String?
    
    var body: some View {
        Button(action: {}) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                    
                    if let trialText = trialText {
                        Text(trialText)
                            .font(.caption)
                            .foregroundColor(.black.opacity(0.7))
                    }
                }
                
                Spacer()
                
                VStack(alignment: .trailing) {
                    Text(price)
                        .font(.title3)
                        .fontWeight(.heavy)
                        .foregroundColor(.black)
                    
                    Text(period)
                        .font(.caption)
                        .foregroundColor(.black.opacity(0.6))
                }
            }
            .padding()
            .background(Color.white)
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(isBestValue ? Color.yellow : Color.clear, lineWidth: isBestValue ? 2 : 0)
            )
            .shadow(color: .white.opacity(0.1), radius: 5)
        }
    }
}

struct PaywallView_Previews: PreviewProvider {
    static var previews: some View {
        PaywallView()
            .environmentObject(StoreManager.shared)
    }
}
