import SwiftUI

struct ReflectionView: View {
    @ObservedObject var viewModel: AppViewModel
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.colorScheme) var colorScheme
    
    // Theme Accessor
    private var theme: AppTheme {
        switch viewModel.uiStyle {
        case .gothic: return GothicThemeImpl()
        case .minimalist: return MinimalistThemeImpl()
        }
    }
    
    // Flow State
    @State private var step: ReflectionStep = .checkEncounter
    
    // Data
    @State private var encountered: Bool = false
    @State private var reflectionText: String = ""
    @State private var selectedOption: RPGOption?
    @State private var selectedFacts: Set<String> = []
    
    enum ReflectionStep {
        case checkEncounter
        case activeForm
        case simulation
        case feedback
    }
    
    // Helper to check content access
    private var canAccessCurrentContent: Bool {
        guard let currentLaw = viewModel.currentLaw else { return false }
        
        // Check if we are in trial period or user is Pro
        if viewModel.canAccessContent(category: viewModel.currentCategory, lawIndex: 0) { // Check general access first
            // Now check specific law index
            if let index = viewModel.allLaws.firstIndex(where: { $0.id == currentLaw.id }) {
                return viewModel.canAccessContent(category: viewModel.currentCategory, lawIndex: index)
            }
        }
        return false
    }
    
    var body: some View {
        ZStack {
            // Background
            theme.backgroundMain.ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header
                HStack {
                    Button(action: { presentationMode.wrappedValue.dismiss() }) {
                        Image(systemName: "xmark")
                            .foregroundColor(theme.textSecondary)
                            .font(.title3)
                    }
                    Spacer()
                    Text(theme.labelWriteProfile)
                        .font(.system(.headline, design: .monospaced))
                        .fontWeight(.bold)
                        .tracking(4)
                        .foregroundColor(theme.style == .gothic ? Color.gothicCardPaper.opacity(0.95) : theme.textPrimary)
                    Spacer()
                    Color.clear.frame(width: 20, height: 20)
                }
                .padding()
                .background(theme.backgroundMain.opacity(0.95))
                
                // Content
                switch step {
                case .checkEncounter:
                    CheckEncounterView(encountered: $encountered, theme: theme, onNext: { didEncounter in
                        self.encountered = didEncounter
                        self.step = didEncounter ? .activeForm : .simulation
                    })
                    .transition(.opacity)
                    
                case .activeForm:
                    ActiveFormView(
                        text: $reflectionText,
                        selectedFacts: $selectedFacts,
                        checklistItems: viewModel.dailyFactChecklistItems,
                        theme: theme,
                        onSubmit: submitActive
                    )
                    .transition(.opacity)
                    
                case .simulation:
                    if let scenario = viewModel.selectedSimulation {
                        SimulationView(scenario: scenario, theme: theme, colorScheme: colorScheme, onSelect: { option in
                            self.selectedOption = option
                            submitSimulation(option: option)
                        })
                        .id(scenario.id) // Force recreate view when scenario changes
                        .transition(.opacity)
                    } else {
                        // All simulations completed for today
                        VStack(spacing: 20) {
                            Spacer()
                            
                            ZStack {
                                Circle()
                                    .stroke(theme.accent.opacity(0.5), lineWidth: 2)
                                    .frame(width: 80, height: 80)
                                
                                Image(systemName: "lock.fill")
                                    .font(.largeTitle)
                                    .foregroundColor(theme.accent)
                            }
                            
                            VStack(spacing: 12) {
                                Text("今日推演已完成")
                                    .font(.system(.title3, design: theme.fontDesign))
                                    .bold()
                                    .foregroundColor(theme.style == .gothic ? Color.gothicCardPaper.opacity(0.95) : theme.textPrimary)
                                
                                Text("请等待明日0点解锁新档案")
                                    .font(.system(.body, design: .monospaced))
                                    .foregroundColor(theme.style == .gothic ? Color.gothicCardPaper.opacity(0.85) : theme.textSecondary)
                            }
                            
                            Divider()
                                .background(theme.textSecondary.opacity(0.3))
                                .padding(.horizontal, 40)
                                .padding(.vertical, 10)
                            
                            // Show encyclopedia interpretation under the divider.
                            // Keep this area scrollable when content is long.
                            if let law = viewModel.currentLaw {
                                ScrollView(.vertical, showsIndicators: true) {
                                    VStack(alignment: .leading, spacing: 10) {
                                        Text(theme.labelSectionPrinciple)
                                            .font(.system(.caption, design: .monospaced))
                                            .foregroundColor(theme.accent)
                                        
                                        Text(law.deepDive?.detailedInterpretation ?? law.detailText)
                                            .font(.system(.body, design: theme.fontDesign))
                                            .foregroundColor(theme.style == .gothic ? Color.gothicCardPaper.opacity(0.92) : theme.textPrimary.opacity(0.9))
                                            .lineSpacing(6)
                                            .multilineTextAlignment(.leading)
                                    }
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding(.horizontal, 30)
                                }
                                .frame(maxHeight: 220)
                            }
                            
                            Spacer()
                            
                            Button(action: { presentationMode.wrappedValue.dismiss() }) {
                                Text("返回观测台")
                                    .font(.system(.headline, design: .monospaced))
                                    .foregroundColor(theme.style == .minimalist ? theme.backgroundMain : theme.textPrimary)
                                    .padding(.horizontal, 30)
                                    .padding(.vertical, 12)
                                    .background(theme.style == .minimalist ? AnyShapeStyle(theme.accent) : theme.cardBackground(isDark: true))
                                    .cornerRadius(2)
                            }
                            .padding(.bottom, 135)
                        }
                    }
                    
                case .feedback:
                    FeedbackView(
                        theme: theme,
                        onClose: { presentationMode.wrappedValue.dismiss() },
                        onNext: { self.step = .simulation },
                        hasNextSimulation: viewModel.selectedSimulation != nil
                    )
                    .transition(.opacity)
                }
            }
        }
        .animation(.easeInOut, value: step)
        .onAppear {
            // LOCK: Double check access on appear
            if !canAccessCurrentContent {
                presentationMode.wrappedValue.dismiss()
                viewModel.showPaywall = true
            }
        }
    }
    
    func submitActive() {
        viewModel.submitDailyRecord(
            type: .active,
            text: reflectionText,
            checklistSelections: Array(selectedFacts)
        )
        step = .feedback
    }
    
    func submitSimulation(option: RPGOption) {
        guard let scenario = viewModel.selectedSimulation else { return }
        viewModel.submitDailyRecord(
            type: .simulation,
            text: "Simulation: \(option.text)",
            simulationScore: option.scoreImpact,
            simulationID: scenario.id,
            optionID: option.id
        )
        // Do NOT change step to .feedback.
        // The ViewModel will update selectedSimulation, triggering the view to refresh or show completion.
    }
}

// Subviews

struct CheckEncounterView: View {
    @Binding var encountered: Bool
    let theme: AppTheme
    let onNext: (Bool) -> Void
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack(spacing: 40) {
            Spacer()
            
            VStack(spacing: 16) {
                if theme.style == .gothic {
                    Image(systemName: "eye.trianglebadge.exclamationmark")
                        .font(.system(size: 60))
                        .foregroundColor(Color.gothicCardPaper.opacity(0.92))
                        .shadow(color: Color.black.opacity(0.35), radius: 2, x: 0, y: 1)
                }
                
                Text("今日实验")
                    .font(.system(.title, design: theme.fontDesign))
                    .bold()
                    .foregroundColor(theme.style == .gothic ? Color.gothicCardPaper.opacity(0.95) : theme.textPrimary)
                
                Text("你在现实生活中是否遇到了类似的场景？")
                    .font(.system(.body, design: .monospaced))
                    .foregroundColor(theme.textSecondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            
            VStack(spacing: 20) {
                Button(action: { onNext(true) }) {
                    Text("是的，我遇到了")
                        .font(.system(.headline, design: .monospaced))
                        .foregroundColor(theme.style == .minimalist ? theme.backgroundMain : theme.textPrimary)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(theme.accent.opacity(0.8))
                        .cornerRadius(theme.cardCornerRadius / 2)
                        .overlay(
                            RoundedRectangle(cornerRadius: theme.cardCornerRadius / 2)
                                .stroke(theme.textPrimary.opacity(0.3), lineWidth: 1)
                        )
                }
                
                Button(action: { onNext(false) }) {
                    Text("进入微小说模拟")
                        .font(.system(.headline, design: .monospaced))
                        .foregroundColor(theme.textPrimary)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(
                            theme.style == .minimalist 
                            ? (theme.cardBackground(isDark: colorScheme == .dark)) // Use context-aware bg
                            : theme.cardBackground(isDark: false) // Keep paper for Gothic
                        )
                        .cornerRadius(theme.cardCornerRadius / 2)
                        .overlay(
                            RoundedRectangle(cornerRadius: theme.cardCornerRadius / 2)
                                .stroke(theme.textPrimary.opacity(0.3), lineWidth: 1)
                        )
                }
            }
            .padding(.horizontal, 40)
            
            Spacer()
        }
    }
}

struct ActiveFormView: View {
    @Binding var text: String
    @Binding var selectedFacts: Set<String>
    let checklistItems: [FactChecklistItem]
    let theme: AppTheme
    let onSubmit: () -> Void
    @Environment(\.colorScheme) private var colorScheme
    @FocusState private var isEditorFocused: Bool
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("记录你的观察")
                        .font(.system(.title2, design: theme.fontDesign))
                        .bold()
                        .foregroundColor(theme.textPrimary)
                    
                    Text("发生了什么？你是如何应对的？你的感受如何？")
                        .font(.system(.caption, design: .monospaced))
                        .foregroundColor(theme.textSecondary)
                }
                .padding(.horizontal)
                .padding(.top, 20)
                
                // Paper Note Area
                ZStack(alignment: .topLeading) {
                    RoundedRectangle(cornerRadius: theme.cardCornerRadius / 2)
                        .fill(theme.cardBackground(isDark: colorScheme == .dark))
                        .overlay(
                            RoundedRectangle(cornerRadius: theme.cardCornerRadius / 2)
                                .stroke(theme.textPrimary.opacity(0.2), lineWidth: 1)
                        )
                    
                    if text.isEmpty {
                        Text("在此处书写...")
                            .font(.system(.body, design: theme.fontDesign))
                            .italic()
                            .foregroundColor(theme.textPrimary.opacity(0.45))
                            .padding(20)
                    }
                    
                    TextEditor(text: $text)
                        .focused($isEditorFocused)
                        .scrollContentBackground(.hidden)
                        .font(.system(.body, design: theme.fontDesign))
                        .foregroundColor(theme.textPrimary)
                        .padding(16)
                        .lineSpacing(6)
                        .frame(minHeight: 180)
                }
                .padding()
                
                VStack(alignment: .leading, spacing: 10) {
                    Text("事实勾选（用于辅计分）")
                        .font(.system(.subheadline, design: .monospaced))
                        .foregroundColor(theme.accent)
                        .padding(.horizontal)
                    
                    ForEach(checklistItems) { item in
                        Button(action: {
                            if selectedFacts.contains(item.id) {
                                selectedFacts.remove(item.id)
                            } else {
                                selectedFacts.insert(item.id)
                            }
                        }) {
                            HStack(spacing: 10) {
                                Image(systemName: selectedFacts.contains(item.id) ? "checkmark.square.fill" : "square")
                                    .foregroundColor(selectedFacts.contains(item.id) ? theme.accent : theme.textSecondary)
                                Text(item.title)
                                    .font(.system(.body, design: theme.fontDesign))
                                    .foregroundColor(theme.textPrimary)
                                Spacer()
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 10)
                            .background(theme.cardBackground(isDark: colorScheme == .dark))
                            .cornerRadius(theme.cardCornerRadius / 2)
                            .overlay(
                                RoundedRectangle(cornerRadius: theme.cardCornerRadius / 2)
                                    .stroke(theme.textPrimary.opacity(0.15), lineWidth: 1)
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal)
                
                Button(action: onSubmit) {
                    HStack {
                        Image(systemName: "envelope.fill")
                        Text("提交档案")
                    }
                    .font(.system(.headline, design: .monospaced))
                    .foregroundColor(theme.style == .minimalist ? theme.backgroundMain : theme.textPrimary)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(text.isEmpty ? Color.gray.opacity(0.3) : theme.accent.opacity(0.9))
                    .cornerRadius(theme.cardCornerRadius / 2)
                    .overlay(
                        RoundedRectangle(cornerRadius: theme.cardCornerRadius / 2)
                            .stroke(theme.textPrimary.opacity(0.3), lineWidth: 1)
                    )
                }
                .disabled(text.isEmpty)
                .padding(.horizontal)
                .padding(.bottom, 20)
            }
        }
        .contentShape(Rectangle())
        .onTapGesture {
            isEditorFocused = false
        }
        .scrollDismissesKeyboard(.interactively)
        .toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("完成") {
                    isEditorFocused = false
                }
            }
        }
    }
}

struct SimulationView: View {
    let scenario: Scenario
    let theme: AppTheme
    let colorScheme: ColorScheme
    let onSelect: (RPGOption) -> Void
    
    @State private var showStory = true
    @State private var showFeedback = false
    @State private var feedbackText = ""
    @State private var shuffledOptions: [RPGOption] = []
    
    var body: some View {
        ZStack {
            if showStory {
                ScrollView {
                    VStack(alignment: .leading, spacing: 0) {
                        // Case File Header
                        HStack {
                            Text("CASE FILE: \(scenario.id.prefix(6).uppercased())")
                                .font(.system(.caption, design: .monospaced))
                                .foregroundColor(theme.style == .gothic ? Color.gothicCardPaper.opacity(0.7) : theme.textSecondary)
                            Spacer()
                            Text(scenario.title)
                                .font(.system(.caption, design: .monospaced))
                                .bold()
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(theme.accent.opacity(0.2))
                                .foregroundColor(theme.accent)
                                .cornerRadius(2)
                        }
                        .padding(.bottom, 20)
                        
                        // Story Text (Typewriter style)
                        Text(scenario.text.replacingOccurrences(of: "{{nickname}}", with: "你"))
                            .font(.system(.body, design: theme.fontDesign))
                            .foregroundColor(theme.style == .gothic ? Color.gothicCardPaper : theme.textPrimary)
                            .lineSpacing(8)
                            .padding(.bottom, 30)
                        
                        Divider()
                            .background(theme.textSecondary.opacity(0.3))
                            .padding(.bottom, 20)
                        
                        Text("抉择时刻")
                            .font(.system(.subheadline, design: .monospaced))
                            .bold()
                            .foregroundColor(theme.accent)
                            .padding(.bottom, 16)
                        
                        ForEach(shuffledOptions) { option in
                            Button(action: { handleSelect(option) }) {
                                HStack {
                                    Text(option.text)
                                        .font(.system(.body, design: theme.fontDesign))
                                        .italic()
                                        .foregroundColor(theme.textPrimary)
                                        .multilineTextAlignment(.leading)
                                        .fixedSize(horizontal: false, vertical: true)
                                    Spacer()
                                    Image(systemName: theme.iconViewClues)
                                        .font(.caption)
                                        .foregroundColor(theme.textPrimary.opacity(0.5))
                                }
                                .padding(16)
                                .background(
                                    theme.style == .minimalist 
                                    ? AnyShapeStyle(colorScheme == .dark ? Color(hex: "1C1C1E") : Color.white)
                                    : theme.cardBackground(isDark: false) // Always paper for options in Gothic
                                )
                                .cornerRadius(theme.cardCornerRadius / 2)
                                .overlay(
                                    RoundedRectangle(cornerRadius: theme.cardCornerRadius / 2)
                                        .stroke(theme.textPrimary.opacity(0.2), lineWidth: 1)
                                )
                                .shadow(color: theme.cardShadow, radius: 2, x: 0, y: 1)
                            }
                            .padding(.bottom, 12)
                        }
                    }
                    .padding(24)
                }
                .transition(.opacity)
            }
            
            if showFeedback {
                VStack {
                    Spacer()
                    
                        Text(feedbackText)
                        .font(.system(.title3, design: theme.fontDesign))
                        .fontWeight(.medium)
                        .italic()
                        .foregroundColor(theme.style == .gothic ? Color.gothicTextInk : theme.textPrimary)
                        .multilineTextAlignment(.center)
                        .lineSpacing(8)
                        .padding(40)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(
                                    theme.style == .minimalist 
                                    ? (colorScheme == .dark ? Color(hex: "1C1C1E") : Color.white.opacity(0.95))
                                    : Color.gothicCardPaper // Light paper for Gothic
                                )
                                .shadow(radius: 10)
                        )
                    
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .transition(.opacity)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onAppear {
            if shuffledOptions.isEmpty {
                shuffledOptions = scenario.options.shuffled()
            }
        }
        .onChange(of: scenario.id) { _, _ in
            shuffledOptions = scenario.options.shuffled()
            withAnimation {
                showStory = true
                showFeedback = false
            }
        }
    }
    
    private func handleSelect(_ option: RPGOption) {
        // 1. Fade out story
        withAnimation(.easeOut(duration: 0.5)) {
            showStory = false
        }
        
        feedbackText = option.outcomeText
        
        // 2. Fade in feedback
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            withAnimation(.easeIn(duration: 0.5)) {
                showFeedback = true
            }
        }
        
        // 3. Wait and submit
        // Timeline: 0.0s (Start) -> 0.5s (Story Hidden, Feedback Start) -> 1.0s (Feedback Fully Visible)
        // User requested 1.5s stay time -> 1.0s + 1.5s = 2.5s Total
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
            onSelect(option)
        }
    }
}

struct FeedbackView: View {
    let theme: AppTheme
    let onClose: () -> Void
    let onNext: () -> Void
    let hasNextSimulation: Bool
    
    var body: some View {
        VStack(spacing: 30) {
            Spacer()
            
            ZStack {
                Circle()
                    .stroke(theme.accent, lineWidth: 3)
                    .frame(width: 100, height: 100)
                
                Image(systemName: "checkmark")
                    .font(.system(size: 50, weight: .bold))
                    .foregroundColor(theme.accent)
            }
            .overlay(
                Text("ARCHIVED")
                    .font(.system(size: 14, weight: .black, design: .monospaced))
                    .foregroundColor(theme.accent)
                    .padding(4)
                    .background(theme.backgroundMain)
                    .offset(y: 50)
            )
            
            VStack(spacing: 10) {
                Text("记录已归档")
                    .font(.system(.title2, design: theme.fontDesign))
                    .bold()
                    .foregroundColor(theme.textPrimary)
                
                Text("你的五维数据已更新。")
                    .font(.system(.body, design: .monospaced))
                    .foregroundColor(theme.textSecondary)
            }
            
            if hasNextSimulation {
                Button(action: onNext) {
                    HStack {
                        Text("进入下一模拟")
                        Image(systemName: "arrow.right")
                    }
                    .font(.system(.headline, design: .monospaced))
                    .foregroundColor(theme.style == .minimalist ? theme.backgroundMain : theme.textPrimary)
                    .padding(.horizontal, 40)
                    .padding(.vertical, 14)
                    .background(theme.accent.opacity(0.9))
                    .cornerRadius(theme.cardCornerRadius / 2)
                    .overlay(
                        RoundedRectangle(cornerRadius: theme.cardCornerRadius / 2)
                            .stroke(theme.textPrimary.opacity(0.3), lineWidth: 1)
                    )
                }
                .padding(.top, 20)
                
                Button(action: onClose) {
                    Text("稍后继续")
                    .font(.system(.caption, design: .monospaced))
                    .foregroundColor(theme.textSecondary)
                    .padding(10)
                }
            } else {
                Button(action: onClose) {
                    Text("关闭档案")
                        .font(.system(.headline, design: .monospaced))
                        .foregroundColor(theme.textPrimary)
                        .padding(.horizontal, 40)
                        .padding(.vertical, 12)
                        .background(theme.cardBackground(isDark: false))
                        .cornerRadius(theme.cardCornerRadius / 2)
                }
                .padding(.top, 20)
            }
            
            Spacer()
        }
    }
}
