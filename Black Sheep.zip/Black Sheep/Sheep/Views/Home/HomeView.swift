import SwiftUI

// MARK: - Gothic Theme Colors
// Colors are now defined in Sheep/Theme/ThemeManager.swift

struct HomeView: View {
    @ObservedObject var viewModel: AppViewModel
    @State private var showReflection = false
    @State private var showGuideOverlay = false
    @Environment(\.colorScheme) var colorScheme
    
    // Theme Accessor
    private var theme: AppTheme {
        switch viewModel.uiStyle {
        case .gothic: return GothicThemeImpl()
        case .minimalist: return MinimalistThemeImpl()
        }
    }
    
    // Random rotation for the overlay card
    @State private var overlayRotation: Double = Double.random(in: -3...3)
    
    // Random rotation for the header "Today's Deduction"
    @State private var headerRotation: Double = Double.random(in: -3...3)
    
    // Card is straight
    @State private var cardRotation: Double = 0
    
    // Random rotation for the CLUE stamp
    @State private var stampRotation: Double = Double.random(in: -45...(-15))
    // Random position offset for the stamp (kept within safe bounds to ensure visibility)
    @State private var stampOffsetX: CGFloat = Double.random(in: -50...50)
    @State private var stampOffsetY: CGFloat = Double.random(in: -80...(-20))
    
    // Helper to check content access
    private var canAccessCurrentContent: Bool {
        guard let currentLaw = viewModel.currentLaw else { return false }
        
        // Check if we are in trial period or user is Pro
        if viewModel.canAccessContent(category: viewModel.currentCategory, lawIndex: 0) { // Check general access first
            // Now check specific law index
            if let index = viewModel.allLaws.firstIndex(where: { $0.id == currentLaw.id }) {
                return viewModel.canAccessContent(category: viewModel.currentCategory, lawIndex: index)
            }
        }
        return false
    }
    
    var body: some View {
        ZStack {
            // Background is handled by MainTabView
            Color.clear
            
            VStack(spacing: 20) {
                // Header: Typewriter style (Straight)
                if theme.showSectionHeaders {
                    Text("今日推演")
                        .font(.system(.title3, design: .monospaced))
                        .fontWeight(.bold)
                        .foregroundColor(theme.style == .gothic ? Color.gothicCardPaper.opacity(0.9) : theme.textPrimary.opacity(0.7))
                        .tracking(6)
                        .padding(.top, 40)
                        .shadow(color: theme.cardShadow, radius: 4, x: 0, y: 2)
                } else {
                    Spacer().frame(height: 40) // Spacing for minimalist
                }
                
                if let law = viewModel.currentLaw {
                    // 2. The Card: Aged Paper Style
                    ZStack {
                        // Paper Texture Background
                        RoundedRectangle(cornerRadius: theme.cardCornerRadius)
                            .fill(theme.cardBackground(isDark: colorScheme == .dark))
                            .overlay(
                                Group {
                                    if theme.showGrain {
                                        GothicNoiseOverlay(opacity: 0.1)
                                    }
                                }
                            )
                            .shadow(color: theme.cardShadow, radius: 5, x: 0, y: 2)
                        
                        // Content
                        ScrollView(.vertical, showsIndicators: false) {
                            VStack(alignment: .leading, spacing: 24) {
                                // Title with decorative lines
                                HStack {
                                    Rectangle().frame(height: 2).frame(width: 30).opacity(0.6)
                                    Text(law.name)
                                        .font(.system(size: 34, weight: .black, design: theme.fontDesign))
                                        .italic()
                                        .shadow(color: theme.textPrimary.opacity(0.2), radius: 1, x: 1, y: 1)
                                        .minimumScaleFactor(0.6)
                                        .lineLimit(2)
                                        .multilineTextAlignment(.center)
                                    Rectangle().frame(height: 2).frame(width: 30).opacity(0.6)
                                }
                                .foregroundColor(theme.textPrimary)
                                .frame(maxWidth: .infinity)
                                
                                // Quote (Handwritten feel)
                                Text("“ \(law.dailyQuote) ”")
                                    .font(.system(.body, design: theme.fontDesign))
                                    .italic()
                                    .fontWeight(.medium)
                                    .foregroundColor(theme.accent)
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .multilineTextAlignment(.center)
                                    .padding(.vertical, 8)
                                    .background(
                                        // Highlight marker effect
                                        theme.accent.opacity(0.05)
                                            .blur(radius: 5)
                                    )
                                
                                Divider()
                                    .background(theme.textPrimary.opacity(0.4))
                                
                                // Section Header
                                HStack {
                                    Image(systemName: "doc.text.magnifyingglass")
                                    Text("档案摘要")
                                }
                                .font(.system(.caption, design: .monospaced))
                                .bold()
                                .foregroundColor(theme.textSecondary)
                                .padding(.top, 4)
                                
                                // Theory Text - NO BLUR, NO LOCK
                                Text(law.detailText)
                                    .font(.system(.body, design: theme.fontDesign))
                                    .foregroundColor(theme.textPrimary.opacity(0.95))
                                    .lineSpacing(8)
                                    .fixedSize(horizontal: false, vertical: true)
                                
                                Spacer(minLength: 30)
                                
                                // Action Button (View Clues) - NO LOCK
                                Button(action: { 
                                    // Re-randomize overlay appearance each time it opens
                                    overlayRotation = Double.random(in: -3...3)
                                    stampRotation = Double.random(in: -45...(-15))
                                    stampOffsetX = Double.random(in: -50...50)
                                    stampOffsetY = Double.random(in: -80...(-20))
                                    
                                    withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) { showGuideOverlay = true } 
                                }) {
                                    HStack(spacing: 12) {
                                        Text(theme.labelViewClues)
                                            .font(.system(.subheadline, design: .monospaced))
                                            .bold()
                                            .tracking(2)
                                        Image(systemName: theme.iconViewClues)
                                            .font(.system(size: 12))
                                    }
                                    .foregroundColor(theme.style == .minimalist ? theme.backgroundMain : theme.textPrimary)
                                    .padding(.vertical, 14)
                                    .frame(maxWidth: .infinity)
                                    .background(
                                        Group {
                                            if theme.style == .minimalist {
                                                Capsule()
                                                    .fill(theme.accent)
                                            } else {
                                                ZStack {
                                                    theme.textPrimary.opacity(0.05)
                                                    RoundedRectangle(cornerRadius: 2)
                                                        .stroke(theme.textPrimary, style: StrokeStyle(lineWidth: 1.5, dash: [4, 4]))
                                                }
                                            }
                                        }
                                    )
                                }
                                .padding(.horizontal, 4)
                            }
                            .padding(32)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .rotationEffect(.degrees(viewModel.uiStyle == .gothic ? cardRotation : 0))
                    .padding(.horizontal, 28)
                    .padding(.bottom, 20)
                    
                    // Bottom Button (Reflection/Black Box) - LOCKED
                    Button(action: { 
                        // LOCK: Reflection Access
                        if !viewModel.canAccessFeature(.reflection) {
                            viewModel.showPaywall = true
                            return
                        }
                        showReflection = true 
                    }) {
                        HStack {
                            Image(systemName: theme.iconWriteProfile)
                            Text(theme.labelWriteProfile)
                        }
                        .font(.system(.headline, design: .monospaced))
                        .foregroundColor(
                            theme.style == .minimalist 
                            ? theme.backgroundMain 
                            : (viewModel.uiStyle == .gothic ? Color.gothicCardPaper : (colorScheme == .dark ? .black : .white))
                        )
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(
                            Group {
                                if theme.style == .minimalist {
                                    Capsule()
                                        .fill(theme.textPrimary) // Black/White button in minimalist
                                } else {
                                    RoundedRectangle(cornerRadius: 4)
                                        .fill(theme.accent.opacity(0.85))
                                }
                            }
                        )
                        .shadow(color: theme.cardShadow, radius: 4, x: 0, y: 2)
                        .overlay(
                            Group {
                                if !viewModel.canAccessFeature(.reflection) {
                                    // Lock Overlay
                                    RoundedRectangle(cornerRadius: 4)
                                        .fill(theme.cardBackground(isDark: colorScheme == .dark).opacity(0.6))
                                        .allowsHitTesting(false)
                                } else if theme.style == .gothic {
                                    RoundedRectangle(cornerRadius: 4)
                                        .stroke(Color.white.opacity(0.4), lineWidth: 1)
                                }
                            }
                        )
                        // Blur applied to the whole button content + background
                        .blur(radius: viewModel.canAccessFeature(.reflection) ? 0 : 3)
                    }
                    .padding(.horizontal, 48)
                    .padding(.bottom, 135) // Match lifted tab bar
                    .sheet(isPresented: $showReflection) {
                        ReflectionView(viewModel: viewModel)
                    }
                    
                } else {
                    // Empty State
                    VStack(spacing: 20) {
                        Image(systemName: "eye.slash")
                        .font(.largeTitle)
                        .foregroundColor(theme.textSecondary)
                        Text("信号丢失...")
                            .font(.system(.body, design: .monospaced))
                            .foregroundColor(theme.textSecondary)
                        
                        if let error = viewModel.dataLoadError {
                            ScrollView {
                                Text(error)
                                    .font(.system(size: 10, design: .monospaced))
                                    .foregroundColor(.red)
                                    .padding()
                            }
                            .frame(height: 200)
                            .background(Color.black.opacity(0.05))
                            .cornerRadius(8)
                            .padding(.horizontal)
                        }
                    }
                }
            }
            
            // Guide Overlay (Clue Card)
            if showGuideOverlay, let dayContent = viewModel.currentDayContent {
                Color.black.opacity(0.85)
                .ignoresSafeArea()
                .onTapGesture {
                    withAnimation { showGuideOverlay = false }
                }
                
                ZStack {
                    // Card Background with Texture
                    RoundedRectangle(cornerRadius: theme.cardCornerRadius)
                        .fill(theme.cardBackground(isDark: colorScheme == .dark))
                        .overlay(
                            RoundedRectangle(cornerRadius: theme.cardCornerRadius)
                                .strokeBorder(theme.textPrimary.opacity(0.2), lineWidth: 8)
                                .blur(radius: 4)
                        )
                        .overlay(
                            Group {
                                if theme.style == .gothic {
                                    // "Top Secret" stamp is Gothic-only.
                                    Text("CLUE")
                                        .font(.system(size: 70, weight: .black, design: .default))
                                        .foregroundColor(theme.accent.opacity(0.08))
                                        .rotationEffect(.degrees(stampRotation))
                                        .offset(x: stampOffsetX, y: stampOffsetY)
                                }
                            }
                        )
                    
                    VStack(alignment: .leading, spacing: 20) {
                        HStack {
                            Group {
                                if theme.style == .gothic {
                                    Text("\(theme.labelClueCard) NO.\(dayContent.dayNumber)")
                                } else {
                                    // Minimalist: Show Law Name directly
                                    Text(viewModel.currentLaw?.name ?? "机制详解")
                                }
                            }
                            .font(.system(.headline, design: .monospaced))
                            .foregroundColor(theme.textSecondary)
                            .padding(6)
                            .background(Color.black.opacity(0.05))
                            .cornerRadius(2)
                            
                            Spacer()
                            
                            Button(action: { withAnimation { showGuideOverlay = false } }) {
                                Image(systemName: "xmark")
                                    .foregroundColor(theme.textPrimary)
                                    .font(.title3)
                            }
                        }
                        
                        Divider().background(theme.textPrimary)
                        
                        Text(dayContent.title)
                            .font(.system(.title2, design: theme.fontDesign))
                            .bold()
                            .foregroundColor(theme.textPrimary)
                        
                        Text(dayContent.actionGuide.replacingOccurrences(of: "今天留意：", with: "").replacingOccurrences(of: "【目的】", with: "").replacingOccurrences(of: "【范围】", with: "\n范围：").replacingOccurrences(of: "【步骤】", with: "\n步骤：").replacingOccurrences(of: "【观察】", with: "\n观察：").replacingOccurrences(of: "【记录】", with: "\n记录：").replacingOccurrences(of: "【边界问题】", with: "\n边界问题："))
                            .font(.system(.body, design: theme.fontDesign))
                            .foregroundColor(theme.textPrimary)
                            .lineSpacing(6)
                        
                        Spacer()
                    }
                    .padding(30)
                }
                .frame(maxWidth: 320, maxHeight: 480)
                .rotationEffect(.degrees(viewModel.uiStyle == .gothic ? overlayRotation : 0))
                .shadow(color: .black, radius: 40)
                .transition(.scale(scale: 0.95).combined(with: .opacity))
            }
        }
    }
}
