import SwiftUI

struct MindPentagonView: View {
    let stats: MindPentagon
    var size: CGFloat = 200
    // Optional theme, if not provided, falls back to Gothic default (for backward compatibility if needed)
    // But ideally we should always pass it.
    var theme: AppTheme? = nil
    @Environment(\.colorScheme) var colorScheme
    
    // Max value for the chart (for normalization)
    private let maxValue: Double = 2000.0
    
    // Resolve Colors
    private var strokeColor: Color {
        if let theme = theme {
            return theme.style == .gothic ? Color.gothicTextInk : theme.textPrimary
        }
        return Color.gothicTextInk
    }
    
    private var fillColor: Color {
        if let theme = theme {
            return theme.style == .gothic ? Color.gothicCardEdge.opacity(0.08) : theme.accent.opacity(0.1)
        }
        return Color.gothicCardEdge.opacity(0.08)
    }
    
    var body: some View {
        ZStack {
            // Background Grid (Web)
            PentagonShape(values: [1, 1, 1, 1, 1], size: size)
                .stroke(strokeColor.opacity(0.3), style: StrokeStyle(lineWidth: 1, dash: [2]))
            
            PentagonShape(values: [0.75, 0.75, 0.75, 0.75, 0.75], size: size)
                .stroke(strokeColor.opacity(0.15), style: StrokeStyle(lineWidth: 1, dash: [2]))
            
            PentagonShape(values: [0.5, 0.5, 0.5, 0.5, 0.5], size: size)
                .stroke(strokeColor.opacity(0.1), style: StrokeStyle(lineWidth: 1, dash: [2]))
            
            // Data Shape - Filled area
            PentagonShape(
                values: [
                    stats.objectivity / maxValue,
                    stats.independence / maxValue,
                    stats.awareness / maxValue,
                    stats.decisiveness / maxValue,
                    stats.reflection / maxValue
                ],
                size: size
            )
            .fill(fillColor)
            
            // Data Shape - Outline
            PentagonShape(
                values: [
                    stats.objectivity / maxValue,
                    stats.independence / maxValue,
                    stats.awareness / maxValue,
                    stats.decisiveness / maxValue,
                    stats.reflection / maxValue
                ],
                size: size
            )
            .stroke(strokeColor.opacity(0.58), style: StrokeStyle(lineWidth: 1.4, lineJoin: .round))
            
            // Labels
            PentagonLabels(size: size, color: strokeColor)
        }
        .frame(width: size, height: size)
    }
}

struct PentagonShape: Shape {
    // Values between 0.0 and 1.0
    // Order: Top, TopRight, BottomRight, BottomLeft, TopLeft
    // Corresponds to: Objectivity, Independence, Awareness, Decisiveness, Reflection
    let values: [Double]
    let size: CGFloat
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let radius = size / 2
        
        // Angles for 5 points (starting from top, -90 degrees)
        let angles = [-90.0, -18.0, 54.0, 126.0, 198.0].map { $0 * .pi / 180.0 }
        
        let points = zip(values, angles).map { (value, angle) -> CGPoint in
            let r = radius * CGFloat(value)
            return CGPoint(
                x: center.x + r * cos(CGFloat(angle)),
                y: center.y + r * sin(CGFloat(angle))
            )
        }
        
        if let first = points.first {
            path.move(to: first)
            for point in points.dropFirst() {
                path.addLine(to: point)
            }
            path.closeSubpath()
        }
        
        return path
    }
}

struct PentagonLabels: View {
    let size: CGFloat
    let color: Color
    
    var body: some View {
        let radius = size / 2 + 25 // Offset labels slightly outside
        let center = CGPoint(x: size/2, y: size/2)
        let angles = [-90.0, -18.0, 54.0, 126.0, 198.0].map { $0 * .pi / 180.0 }
        let labels = ["客观", "独立", "觉察", "决断", "反思"]
        
        return ZStack {
            ForEach(0..<5) { i in
                Text(labels[i])
                    .font(.system(size: 10, design: .monospaced))
                    .bold()
                    .foregroundColor(color.opacity(0.8))
                    .position(
                        x: center.x + radius * cos(CGFloat(angles[i])),
                        y: center.y + radius * sin(CGFloat(angles[i]))
                    )
            }
        }
    }
}
