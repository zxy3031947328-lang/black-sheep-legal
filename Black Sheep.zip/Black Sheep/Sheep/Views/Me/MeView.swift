import SwiftUI
import PhotosUI
import UIKit
import FirebaseAuth

struct MeView: View {
    @ObservedObject var viewModel: AppViewModel
    @StateObject private var authService = AuthService.shared // Auth
    @State private var showSettings = false
    @State private var showLogin = false // Login Sheet
    @Environment(\.colorScheme) var colorScheme
    
    // ... (Existing AppStorage props)
    @AppStorage("user_joined_at") private var joinedAtTimestamp: Double = 0
    @AppStorage("user_nickname") private var nickname: String = "迷失者"
    @AppStorage("user_avatar_symbol") private var avatarSymbol: String = "person.fill"
    @AppStorage("user_avatar_image_data") private var avatarImageData: Data = Data()
    
    // ... (Theme Accessor & Random props)
    private var theme: AppTheme {
        switch viewModel.uiStyle {
        case .gothic: return GothicThemeImpl()
        case .minimalist: return MinimalistThemeImpl()
        }
    }
    
    // Random elements for the ID card look
    @State private var cardRotation: Double = Double.random(in: -1...1)
    @State private var stampRotation: Double = Double.random(in: -20...(-10))
    @State private var fingerprintOpacity: Double = Double.random(in: 0.1...0.2)
    
    private var joinedDate: Date {
        if let user = authService.currentUser {
            return user.metadata.creationDate ?? Date()
        }
        if joinedAtTimestamp > 0 {
            return Date(timeIntervalSince1970: joinedAtTimestamp)
        }
        return Date()
    }
    
    private var displayEmail: String {
        if let user = authService.currentUser, let email = user.email {
            return email
        }
        return "未登录访客"
    }
    
    // ... (Existing helper vars)
    private var currentLevel: Int {
        let elapsedHours = max(0, Date().timeIntervalSince(joinedDate) / 3600)
        return Int(elapsedHours / 24) + 1
    }
    
    private var uploadedAvatarImage: UIImage? {
        guard !avatarImageData.isEmpty else { return nil }
        return UIImage(data: avatarImageData)
    }
    
    private var resolvedAvatarSymbol: String {
        UIImage(systemName: avatarSymbol) == nil ? "person.fill" : avatarSymbol
    }

    private func clearLocalProfileData() {
        joinedAtTimestamp = 0
        nickname = "迷失者"
        avatarSymbol = "person.fill"
        avatarImageData = Data()
    }

    private func deleteAccount(password: String) async throws {
        try await viewModel.deleteCurrentAccount(password: password)
        await MainActor.run {
            clearLocalProfileData()
            showSettings = false
        }
    }
    
    var body: some View {
        ZStack {
            // Background is handled by MainTabView
            Color.clear
            
            VStack(spacing: 0) {
                // Header
                if !theme.labelTitleMe.isEmpty {
                    HStack {
                        Image(systemName: "person.crop.rectangle.fill")
                            .font(.title2)
                        Text(theme.labelTitleMe)
                            .font(.system(.title2, design: .monospaced))
                            .fontWeight(.bold)
                            .tracking(4)
                    }
                    .foregroundColor(theme.style == .gothic ? Color.gothicCardPaper.opacity(0.9) : theme.textPrimary.opacity(0.8))
                    .padding(.top, 20)
                    .padding(.bottom, 30)
                } else {
                    Spacer().frame(height: 40) // Spacing for minimalist
                }
                
                // 2. The ID Card / Dossier
                ZStack {
                    // Card Background
                    RoundedRectangle(cornerRadius: theme.cardCornerRadius)
                        .fill(theme.cardBackground(isDark: colorScheme == .dark))
                        .overlay(
                            // Simple Noise Overlay
                            Group {
                                if theme.showGrain {
                                    GothicNoiseOverlay(opacity: 0.1)
                                }
                            }
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: theme.cardCornerRadius)
                                .strokeBorder(theme.cardBorder, lineWidth: 1)
                        )
                        .shadow(color: theme.cardShadow, radius: 8, x: 0, y: 4)
                    
                    // Edge Burn (Gothic Only)
                    if theme.showEdgeBurn {
                        RoundedRectangle(cornerRadius: theme.cardCornerRadius)
                            .stroke(Color.black.opacity(0.3), lineWidth: 4)
                            .blur(radius: 6)
                            .mask(RoundedRectangle(cornerRadius: theme.cardCornerRadius))
                    }
                    
                    VStack(spacing: 24) {
                        // Top Section: Photo & Basic Info
                        HStack(alignment: .top, spacing: 20) {
                            // Photo Area
                            ZStack {
                                Rectangle()
                                    .fill(theme.textPrimary.opacity(0.1))
                                    .frame(width: 80, height: 100)
                                    .overlay(
                                        Rectangle()
                                            .stroke(theme.textPrimary.opacity(0.3), lineWidth: 1)
                                    )
                                
                                Group {
                                    if let uploadedAvatarImage {
                                        Image(uiImage: uploadedAvatarImage)
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: 72, height: 92)
                                            .clipShape(RoundedRectangle(cornerRadius: 4))
                                    } else {
                                        Image(systemName: resolvedAvatarSymbol)
                                            .font(.system(size: 40))
                                            .foregroundColor(theme.textPrimary.opacity(0.4))
                                    }
                                }
                                
                                // "Stamp" over photo
                                if theme.showAuthStamp {
                                    Text(authService.isAuthenticated ? "AUTH" : "VOID")
                                        .font(.system(size: 10, weight: .black, design: .monospaced))
                                        .foregroundColor(authService.isAuthenticated ? theme.accent.opacity(0.6) : .red.opacity(0.6))
                                        .padding(2)
                                        .border(authService.isAuthenticated ? theme.accent.opacity(0.6) : .red.opacity(0.6), width: 1)
                                        .rotationEffect(.degrees(-30))
                                        .offset(x: 20, y: 30)
                                }
                            }
                            
                            // Info Text
                            VStack(alignment: .leading, spacing: 8) {
                                HStack(alignment: .firstTextBaseline, spacing: 8) {
                                    Text(theme.labelID + ":")
                                        .font(.system(.caption, design: .monospaced))
                                        .foregroundColor(theme.textSecondary)
                                        .fixedSize()

                                    Text(nickname)
                                        .font(.system(.body, design: theme.fontDesign))
                                        .bold()
                                        .foregroundColor(theme.textPrimary)
                                        .lineLimit(1)
                                        .minimumScaleFactor(0.6)

                                    Button {
                                        if !viewModel.isPro {
                                            viewModel.showPaywall = true
                                        }
                                    } label: {
                                        MembershipBadge(isPro: viewModel.isPro, theme: theme)
                                    }
                                    .buttonStyle(.plain)
                                }
                                InfoRow(label: theme.labelLevel, value: theme.levelPrefix + String(currentLevel) + theme.labelLevelSuffix, theme: theme)
                                InfoRow(label: "状态", value: authService.isAuthenticated ? "已登录" : "游客", theme: theme)
                            }
                            .padding(.top, 4)
                            
                            Spacer()
                        }
                        .padding(.horizontal, 24)
                        .padding(.top, 24)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            if !authService.isAuthenticated {
                                showLogin = true
                            }
                        }
                        
                        Divider()
                            .background(theme.textPrimary.opacity(0.3))
                            .padding(.horizontal, 24)
                        
                        // Middle Section: Stats (Psych Evaluation)
                        VStack(spacing: 12) {
                            Text("精神评估报告")
                                .font(.system(.caption, design: .monospaced))
                                .bold()
                                .foregroundColor(theme.textPrimary.opacity(0.6))
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.horizontal, 24)
                            
                            if !viewModel.localStore.progress.hasCompletedOnboarding {
                                ZStack {
                                    MindPentagonView(
                                        stats: MindPentagon(objectivity: 2000, independence: 2000, awareness: 2000, decisiveness: 2000, reflection: 2000),
                                        size: 180,
                                        theme: theme
                                    )
                                    .frame(height: 180)
                                    .blur(radius: 12)
                                    .opacity(0.5)
                                    
                                    VStack(spacing: 12) {
                                        Image(systemName: "lock.fill")
                                            .font(.system(size: 28))
                                            .foregroundColor(theme.textPrimary)
                                        
                                        Text("建立初始档案")
                                            .font(.system(.subheadline, design: .monospaced))
                                            .bold()
                                            .foregroundColor(theme.textPrimary)
                                    }
                                }
                                .frame(height: 180)
                                .contentShape(Rectangle())
                                .onTapGesture {
                                    viewModel.showOnboarding = true
                                }
                            } else {
                                MindPentagonView(stats: viewModel.localStore.progress.totalStats, size: 180, theme: theme)
                                    .frame(height: 180)
                                    .blur(radius: viewModel.canAccessFeature(.mindPentagon) ? 0 : 8)
                                    .overlay(
                                        Group {
                                            if !viewModel.canAccessFeature(.mindPentagon) {
                                                Color.white.opacity(0.001) // Invisible hit target
                                                    .onTapGesture {
                                                        viewModel.showPaywall = true
                                                    }
                                            }
                                        }
                                    )
                            }
                        }
                        
                        Divider()
                            .background(theme.textPrimary.opacity(0.3))
                            .padding(.horizontal, 24)
                        
                        // Bottom Section: Actions
                        VStack(alignment: .leading, spacing: 12) {
                            Text("操作权限")
                                .font(.system(.caption, design: .monospaced))
                                .bold()
                                .foregroundColor(theme.textPrimary.opacity(0.6))
                                .padding(.horizontal, 24)
                            
                            HStack(spacing: 16) {
                                ActionButton(icon: "gearshape.fill", label: "设置", theme: theme) {
                                    showSettings = true
                                }
                                
                                // Login / Logout Button
                                if authService.isAuthenticated {
                                    ActionButton(icon: "rectangle.portrait.and.arrow.right", label: "登出", theme: theme) {
                                        Task {
                                            try? await authService.signOut()
                                        }
                                    }
                                } else {
                                    ActionButton(icon: "person.crop.circle.badge.plus", label: "登录", theme: theme) {
                                        showLogin = true
                                    }
                                }
                            }
                            .padding(.horizontal, 24)
                            .padding(.bottom, 24)
                        }
                    }
                    
                    // Fingerprint overlay (subtle) - Gothic Only
                    if theme.style == .gothic {
                        Image(systemName: "touchid")
                            .font(.system(size: 120))
                            .foregroundColor(theme.textPrimary.opacity(fingerprintOpacity))
                            .rotationEffect(.degrees(15))
                            .offset(x: 100, y: 150)
                        
                        // "CONFIDENTIAL" Stamp - Gothic Only
                        Text("CONFIDENTIAL")
                            .font(.system(size: 24, weight: .black, design: .monospaced))
                            .foregroundColor(theme.accent.opacity(0.15))
                            .rotationEffect(.degrees(stampRotation))
                            .offset(x: -20, y: -180)
                    }
                }
                .frame(maxWidth: 340)
                .rotationEffect(.degrees(viewModel.uiStyle == .gothic ? cardRotation : 0)) // No rotation in minimalist
                .padding(.bottom, 135) // Match lifted tab bar
                
                Spacer()
            }
        }
        .onAppear {
            if joinedAtTimestamp <= 0 {
                joinedAtTimestamp = Date().timeIntervalSince1970
            }
            if UIImage(systemName: avatarSymbol) == nil {
                avatarSymbol = "person.fill"
            }
        }
        .sheet(isPresented: $showSettings) {
            MeSettingsView(
                uiStyle: $viewModel.uiStyle,
                canUseGothic: viewModel.canAccessFeature(.gothicStyle),
                showPaywall: $viewModel.showPaywall,
                nickname: $nickname,
                avatarSymbol: $avatarSymbol,
                avatarImageData: $avatarImageData,
                joinedAtTimestamp: $joinedAtTimestamp,
                canDeleteAccount: authService.isAuthenticated,
                accountEmail: authService.currentUser?.email,
                deleteAccountAction: { password in
                    try await deleteAccount(password: password)
                }
            )
            .presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $showLogin) {
            LoginView(uiStyle: viewModel.uiStyle)
        }
    }
}

struct InfoRow: View {
    let label: String
    let value: String
    let theme: AppTheme
    var valueFont: Font? = nil
    
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text(label + ":")
                .font(.system(.caption, design: .monospaced))
                .foregroundColor(theme.textSecondary)
                .fixedSize() // Ensure label doesn't truncate
            Text(value)
                .font(valueFont ?? .system(.body, design: theme.fontDesign))
                .bold()
                .foregroundColor(theme.textPrimary)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
        }
    }
}

struct ActionButton: View {
    let icon: String
    let label: String
    let theme: AppTheme
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                Text(label)
            }
            .font(.system(.caption, design: .monospaced))
            .foregroundColor(theme.textPrimary)
            .padding(.vertical, 8)
            .padding(.horizontal, 16)
            .background(theme.textPrimary.opacity(0.05))
            .overlay(
                RoundedRectangle(cornerRadius: 2)
                    .stroke(theme.textPrimary.opacity(0.3), lineWidth: 1)
            )
        }
    }
}

struct MembershipBadge: View {
    let isPro: Bool
    let theme: AppTheme

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: isPro ? "checkmark.seal.fill" : "sparkles")
                .font(.system(size: 10, weight: .bold))
            Text(isPro ? "VIP" : "订阅")
                .font(.system(size: 10, weight: .bold, design: .monospaced))
        }
        .foregroundColor(isPro ? theme.backgroundMain : theme.textPrimary)
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(
            Capsule()
                .fill(isPro ? theme.accent : theme.textPrimary.opacity(0.08))
        )
        .overlay(
            Capsule()
                .stroke(isPro ? theme.accent.opacity(0.8) : theme.textPrimary.opacity(0.2), lineWidth: 1)
        )
    }
}

struct MeSettingsView: View {
    @Binding var uiStyle: UIStyle
    let canUseGothic: Bool
    @Binding var showPaywall: Bool
    @Binding var nickname: String
    @Binding var avatarSymbol: String
    @Binding var avatarImageData: Data
    @Binding var joinedAtTimestamp: Double
    let canDeleteAccount: Bool
    let accountEmail: String?
    let deleteAccountAction: (String) async throws -> Void
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var colorScheme
    @State private var selectedPhotoItem: PhotosPickerItem?
    @State private var showDeleteConfirmation = false
    @State private var showDeletePasswordSheet = false
    @State private var deletePassword = ""
    @State private var deleteError: String?
    @State private var isDeletingAccount = false
    @ObservedObject private var storeManager = StoreManager.shared

    private var theme: AppTheme {
        switch uiStyle {
        case .gothic: return GothicThemeImpl()
        case .minimalist: return MinimalistThemeImpl()
        }
    }
    
    private let avatarOptions: [String] = [
        "person.fill",
        "person.circle.fill",
        "person.crop.circle.fill",
        "person.crop.square.fill",
        "heart.fill",
        "star.fill",
        "bolt.fill",
        "moon.stars.fill"
    ]
    
    private var availableAvatarOptions: [String] {
        avatarOptions.filter { UIImage(systemName: $0) != nil }
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section("界面风格") {
                    Picker("风格", selection: $uiStyle) {
                        Text("哥特").tag(UIStyle.gothic)
                        Text("极简").tag(UIStyle.minimalist)
                    }
                    .pickerStyle(.segmented)

                    if !canUseGothic {
                        Text("哥特风格可在 7 天试用期内使用，第 8 天起需要付费解锁。")
                            .font(.footnote)
                            .foregroundColor(theme.textSecondary)
                    }
                }

                Section("昵称") {
                    TextField("输入昵称", text: $nickname)
                        .onChange(of: nickname) { _, newValue in
                            nickname = String(newValue.prefix(24))
                        }
                }
                
                Section("头像") {
                    PhotosPicker(
                        selection: $selectedPhotoItem,
                        matching: .images,
                        photoLibrary: .shared()
                    ) {
                        HStack {
                            Image(systemName: "photo.on.rectangle")
                            Text("从相册上传头像")
                        }
                        .font(.system(.body, design: .default))
                    }
                    
                    if !avatarImageData.isEmpty {
                        Button("使用预设头像") {
                            avatarImageData = Data()
                        }
                        .foregroundColor(theme.accentDestructive)
                    }
                    
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 52), spacing: 12)], spacing: 12) {
                        ForEach(availableAvatarOptions, id: \.self) { option in
                            Button(action: { avatarSymbol = option }) {
                                Image(systemName: option)
                                    .font(.system(size: 24))
                                    .foregroundColor(theme.textPrimary)
                                    .frame(width: 44, height: 44)
                                    .background(
                                        Circle()
                                            .fill(theme.cardBackground(isDark: colorScheme == .dark))
                                    )
                                    .overlay(
                                        Circle()
                                            .stroke(avatarSymbol == option ? theme.accent : theme.textSecondary.opacity(0.2), lineWidth: avatarSymbol == option ? 2 : 1)
                                    )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.vertical, 4)
                }

                Section("会员与购买") {
                    Button {
                        dismiss()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                            showPaywall = true
                        }
                    } label: {
                        HStack {
                            Label(storeManager.isPro ? "查看会员权益" : "查看订阅方案", systemImage: storeManager.isPro ? "checkmark.seal.fill" : "sparkles")
                            Spacer()
                            if storeManager.isPro {
                                Text("VIP")
                                    .font(.caption.monospaced())
                                    .foregroundColor(theme.accent)
                            }
                        }
                    }

                    Button {
                        Task {
                            await storeManager.restorePurchases()
                        }
                    } label: {
                        Label("恢复购买", systemImage: "arrow.clockwise")
                    }
                }
                
                if canDeleteAccount {
                    Section("危险操作") {
                        Button(role: .destructive) {
                            showDeleteConfirmation = true
                        } label: {
                            Text("删除账号与云端数据")
                        }

                        Text("此操作将删除当前账号、云端同步进度、日记录以及本地资料，且无法恢复。不会取消 Apple 订阅，也不会重置 7 天试用。")
                            .font(.footnote)
                            .foregroundColor(theme.textSecondary)
                    }
                }
            }
            .navigationTitle("个人设置")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成") { dismiss() }
                }
            }
        }
        .confirmationDialog(
            "确认删除账号？",
            isPresented: $showDeleteConfirmation,
            titleVisibility: .visible
        ) {
            Button("继续删除", role: .destructive) {
                deletePassword = ""
                deleteError = nil
                showDeletePasswordSheet = true
            }
            Button("取消", role: .cancel) {}
        } message: {
            Text("此操作会删除当前账号、云端数据和本地资料，但不会取消 Apple 订阅，也不会重置试用期。")
        }
        .sheet(isPresented: $showDeletePasswordSheet) {
            NavigationView {
                Form {
                    Section("删除确认") {
                        Text("请输入当前账号密码以确认删除。")
                            .foregroundColor(theme.textSecondary)

                        if let accountEmail {
                            LabeledContent("账号", value: accountEmail)
                        }

                        SecureField("当前密码", text: $deletePassword)
                            .textContentType(.password)
                    }

                    if let deleteError {
                        Section {
                            Text(deleteError)
                                .foregroundColor(.red)
                        }
                    }

                    Section {
                        Button(role: .destructive) {
                            performDeleteAccount()
                        } label: {
                            if isDeletingAccount {
                                HStack {
                                    Spacer()
                                    ProgressView()
                                    Spacer()
                                }
                            } else {
                                Text("确认删除账号")
                            }
                        }
                        .disabled(isDeletingAccount || deletePassword.isEmpty)
                    }
                }
                .navigationTitle("删除账号")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("取消") {
                            showDeletePasswordSheet = false
                        }
                        .disabled(isDeletingAccount)
                    }
                }
            }
            .interactiveDismissDisabled(isDeletingAccount)
        }
        .onChange(of: selectedPhotoItem) { _, newItem in
            guard let newItem else { return }
            Task {
                if let data = try? await newItem.loadTransferable(type: Data.self) {
                    await MainActor.run {
                        avatarImageData = data
                    }
                }
            }
        }
        .onChange(of: uiStyle) { oldValue, newValue in
            guard newValue == .gothic, !canUseGothic else { return }
            uiStyle = oldValue == .gothic ? .minimalist : oldValue
            showPaywall = true
        }
        .onAppear {
            if !canUseGothic && uiStyle == .gothic {
                uiStyle = .minimalist
            }
        }
    }

    private func performDeleteAccount() {
        deleteError = nil

        Task {
            await MainActor.run {
                isDeletingAccount = true
            }

            do {
                try await deleteAccountAction(deletePassword)
                await MainActor.run {
                    joinedAtTimestamp = 0
                    showDeletePasswordSheet = false
                    dismiss()
                }
            } catch {
                await MainActor.run {
                    deleteError = deleteErrorMessage(from: error)
                }
            }

            await MainActor.run {
                isDeletingAccount = false
            }
        }
    }

    private func deleteErrorMessage(from error: Error) -> String {
        let nsError = error as NSError

        guard nsError.domain == AuthErrorDomain,
              let code = AuthErrorCode(rawValue: nsError.code) else {
            return error.localizedDescription
        }

        switch code {
        case .wrongPassword, .invalidCredential:
            return "当前密码不正确，请重新输入。"
        case .networkError:
            return "网络连接异常，请稍后重试。"
        case .requiresRecentLogin:
            return "登录状态已过期，请重新登录后再删除账号。"
        default:
            return error.localizedDescription
        }
    }
}
