import Foundation
import Combine
import FirebaseAuth

class AppViewModel: ObservableObject {
    private enum DailyScoreConfig {
        static let simulationWeight: Double = 0.7
        static let checklistWeight: Double = 0.3
        static let simulationScale: Double = 8.0
        static let checklistScale: Double = 8.0
        static let perDimensionDailyCap: Double = 24.0
        static let totalDailyCap: Double = 80.0
    }
    
    private enum TrialKeys {
        static let firstLaunchDate = "first_launch_date"
    }
    
    // MARK: - Core State
    @Published var currentLaw: Law?
    @Published var currentDay: Int?
    @Published var currentDayContent: Law.DayContent?
    
    // For random simulation selection
    @Published var selectedSimulation: Scenario?
    
    // Track completed simulations for the current day
    @Published var completedSimulationIDs: Set<String> = []
    
    // MARK: - Global Flags
    @Published var showOnboarding: Bool = false
    @Published var uiStyle: UIStyle = .minimalist // Default style
    @Published var dataLoadError: String? // For debugging
    @Published var currentCategory: LawCategory = .socialInfluence // Default category

    // MARK: - Auth & Sync
    let authService = AuthService.shared
    let firestoreService = FirestoreService.shared
    @Published var isSyncing: Bool = false
    
    // MARK: - Dependencies
    private let lawRepository = LawRepository.shared
    let localStore: LocalStore
    
    // StoreKit Integration
    @Published var isPro: Bool = false
    @Published var showPaywall: Bool = false
    
    // Trial Logic
    private let trialDuration: TimeInterval = 7 * 24 * 60 * 60 // 7 Days
    
    var isTrialPeriod: Bool {
        // Production Logic:
        guard let firstLaunch = UserDefaults.standard.object(forKey: TrialKeys.firstLaunchDate) as? Date else {
            // If date is missing (shouldn't happen due to init), treat as new user (Trial Active)
            return true 
        }
        
        let elapsed = Date().timeIntervalSince(firstLaunch)
        return elapsed < trialDuration
    }
    
    private var cancellables = Set<AnyCancellable>()
    
    init() {
        self.localStore = LocalStore()
        
        // Initialize First Launch Date
        if UserDefaults.standard.object(forKey: TrialKeys.firstLaunchDate) == nil {
            UserDefaults.standard.set(Date(), forKey: TrialKeys.firstLaunchDate)
        }
        
        // Sync isPro with StoreManager
        StoreManager.shared.$isPro
            .receive(on: RunLoop.main)
            .assign(to: \.isPro, on: self)
            .store(in: &cancellables)
        
        // Temporary Debug: Reset data if running for the first time with this fix
        // Changed key to force reset for daily limit fix (v4 for new data architecture)
        if !UserDefaults.standard.bool(forKey: "v4_data_reset_new_arch") {
            print("DEBUG: Performing one-time data reset for new architecture.")
            self.localStore.resetProgress()
            UserDefaults.standard.set(true, forKey: "v4_data_reset_new_arch")
        }
        
        // Forward LocalStore changes
        self.localStore.objectWillChange
            .sink { [weak self] _ in
                self?.objectWillChange.send()
            }
            .store(in: &cancellables)
            
        // Forward LawRepository changes
        self.lawRepository.$laws
            .receive(on: RunLoop.main)
            .sink { [weak self] _ in
                self?.objectWillChange.send()
                self?.restoreState()
            }
            .store(in: &cancellables)
            
        // Forward LawRepository errors
        self.lawRepository.$lastError
            .receive(on: RunLoop.main)
            .assign(to: &$dataLoadError)
        
        // Check Onboarding
        // self.showOnboarding = !localStore.progress.hasCompletedOnboarding
        
        // Listen to Auth Changes
        authService.$currentUser
            .receive(on: RunLoop.main)
            .sink { [weak self] user in
                if let user = user {
                    print("Auth: User logged in: \(user.uid)")
                    // Trigger sync when user logs in
                    Task {
                        await self?.syncWithCloud(uid: user.uid)
                    }
                } else {
                    print("Auth: User logged out")
                    // Optional: Clear local data or switch to anonymous mode?
                    // For now, we keep local data as is (offline mode)
                }
            }
            .store(in: &cancellables)
            
        // Load Data
        // Load default category, or saved category if implemented
        let initialCategory = UserDefaults.standard.string(forKey: "last_category") ?? "social_influence"
        self.currentCategory = LawCategory(rawValue: initialCategory) ?? .socialInfluence
        
        Task {
            await lawRepository.loadCategoryInitialData(category: self.currentCategory.rawValue)
        }
        
        // Restore State (initial attempt, might be empty until laws load)
        restoreState()
    }
    
    // MARK: - State Management
    
    func restoreState() {
        print("DEBUG: restoreState called")
        
        // Check for day advancement first
        checkAndAdvanceDays()
        
        print("DEBUG: activeLawID from store: \(localStore.progress.activeLawID ?? "nil")")
        print("DEBUG: laws count in repo: \(lawRepository.laws.count)")
        
        // If we have an active law saved in progress, load it
        if let activeLawID = localStore.progress.activeLawID,
           let law = lawRepository.getLaw(by: activeLawID) {
            print("DEBUG: Found active law: \(law.name)")
            
            // Reset simulation if law changed
            if self.currentLaw?.id != law.id {
                self.selectedSimulation = nil
                self.completedSimulationIDs.removeAll()
            }
            
            self.currentLaw = law
            
            let day = localStore.progress.lawProgress[activeLawID] ?? 1
            self.currentDay = day
            
            // Restore completed simulations from daily records for this law and day
            let completedSims = localStore.dailyRecords
                .filter { $0.lawID == activeLawID && $0.dayNumber == day && $0.type == .simulation }
                .compactMap { $0.simulationID }
            
            self.completedSimulationIDs = Set(completedSims)
            print("DEBUG: Restored completed simulations: \(self.completedSimulationIDs)")
            
            // Find content for this day
            if let content = law.dayStages.first(where: { $0.dayNumber == day }) {
                self.currentDayContent = content
                
                // Check if today is already "completed" (waiting for next day)
                let todayStart = Calendar.current.startOfDay(for: Date())
                if let lastCompletion = localStore.progress.lastCompletionDate[activeLawID],
                   lastCompletion >= todayStart {
                    // Today is completed, wait for tomorrow
                    self.selectedSimulation = nil
                    print("DEBUG: Day completed, waiting for tomorrow.")
                } else {
                    // Find the first simulation that hasn't been completed yet
                    if let nextSim = content.simulations.first(where: { !self.completedSimulationIDs.contains($0.id) }) {
                        self.selectedSimulation = nextSim
                        print("DEBUG: Selected next simulation: \(nextSim.id)")
                    } else {
                        // All simulations for today are done, but maybe not marked as completed in lastCompletionDate yet?
                        // This case should be handled by submitDailyRecord, but as a fallback:
                        self.selectedSimulation = nil
                        print("DEBUG: No more simulations for today or all completed.")
                    }
                }
            } else {
                print("DEBUG: Day content not found for day \(day)")
            }
        } else {
            print("DEBUG: Active law NOT found in repo or ID is nil")
            // If no active law, pick the first available one
            if let firstLaw = lawRepository.laws.first {
                print("DEBUG: Starting first law: \(firstLaw.name)")
                startLaw(firstLaw)
            }
        }
        
        // DEBUG: Force unlock check removed for production
        // let allIDs = lawRepository.laws.map { $0.id }
        // ... (Removed force unlock logic)
    }
    
    private func checkAndAdvanceDays() {
        guard let activeLawID = localStore.progress.activeLawID else { return }
        
        // Check if we have a pending completion
        if let lastCompletion = localStore.progress.lastCompletionDate[activeLawID] {
            let todayStart = Calendar.current.startOfDay(for: Date())
            
            // If the last completion was BEFORE today (i.e., yesterday or earlier), we can advance
            if lastCompletion < todayStart {
                print("DEBUG: Advancing day for law \(activeLawID) because new day arrived.")
                
                // Check if current day was Day 3 (Law completed)
                let currentDay = localStore.progress.lawProgress[activeLawID] ?? 1
                
                if currentDay >= 3 {
                    // Law Completed Logic
                    var progress = localStore.progress
                    progress.unlockedLawIDs.insert(activeLawID)
                    
                    // Find next law
                    if let currentIndex = allLaws.firstIndex(where: { $0.id == activeLawID }),
                       currentIndex + 1 < allLaws.count {
                        let nextLaw = allLaws[currentIndex + 1]
                        print("DEBUG: Switching to next law: \(nextLaw.name) (ID: \(nextLaw.id))")
                        
                        progress.activeLawID = nextLaw.id
                        if progress.lawProgress[nextLaw.id] == nil {
                            progress.lawProgress[nextLaw.id] = 1
                        }
                    } else {
                        print("DEBUG: No next law found or end of list.")
                    }
                    
                    // Clear completion date for the OLD law (since we switched)
                    // And we don't need it for the new law yet.
                    progress.lastCompletionDate.removeValue(forKey: activeLawID)
                    localStore.saveProgress(progress)
                    
                } else {
                    // Normal Day Advance (e.g. Day 1 -> Day 2)
                    localStore.advanceDay(for: activeLawID)
                    
                    var progress = localStore.progress
                    progress.lastCompletionDate.removeValue(forKey: activeLawID)
                    localStore.saveProgress(progress)
                }
                
                // Reset local state
                self.completedSimulationIDs.removeAll()
            }
        }
    }
    
    func startLaw(_ law: Law) {
        var progress = localStore.progress
        progress.activeLawID = law.id
        // Ensure the law is unlocked when started manually
        progress.unlockedLawIDs.insert(law.id)
        
        if progress.lawProgress[law.id] == nil {
            progress.lawProgress[law.id] = 1
        }
        localStore.saveProgress(progress)
        completedSimulationIDs.removeAll()
        restoreState()
    }
    
    func completeOnboarding(initialStats: MindPentagon) {
        var newProgress = localStore.progress
        newProgress.totalStats = initialStats
        newProgress.hasCompletedOnboarding = true
        // Unlock first category's laws immediately upon onboarding completion
        if let firstLaw = lawRepository.laws.first {
            newProgress.unlockedLawIDs.insert(firstLaw.id)
            newProgress.activeLawID = firstLaw.id
            newProgress.lawProgress[firstLaw.id] = 1
        }
        localStore.saveProgress(newProgress)
        showOnboarding = false
        restoreState()
    }
    
    // MARK: - Actions
    
    func submitDailyRecord(
        type: RecordType,
        text: String,
        simulationScore: MindPentagon = .zero,
        checklistSelections: [String] = [],
        simulationID: String? = nil,
        optionID: String? = nil
    ) {
        guard let law = currentLaw, let day = currentDay else { return }
        let finalScore = calculateDailyScore(
            lawID: law.id,
            day: day,
            type: type,
            simulationScore: simulationScore,
            checklistSelections: checklistSelections
        )
        
        // 1. Save the record
        let record = DailyRecord(
            id: UUID(),
            lawID: law.id,
            dayNumber: day,
            type: type,
            textContent: text,
            factChecklistSelections: checklistSelections.isEmpty ? nil : checklistSelections,
            simulationOptionID: optionID,
            simulationID: simulationID,
            scoreGained: finalScore,
            createdAt: Date()
        )
        
        localStore.addRecord(record)
        
        // 1.5. Upload to Cloud (if authenticated)
        if let currentUser = authService.currentUser {
            let userUID = currentUser.uid
            Task {
                try? await firestoreService.saveDailyRecord(uid: userUID, record: record)
                try? await firestoreService.saveProgress(uid: userUID, progress: localStore.progress)
            }
        }
        
        // 2. Mark current simulation as completed
        if type == .simulation {
            if let simID = simulationID {
                completedSimulationIDs.insert(simID)
            } else if let currentSimID = selectedSimulation?.id {
                // Fallback if simulationID not passed but selectedSimulation exists
                completedSimulationIDs.insert(currentSimID)
            }
        }
        
        // 3. Check if all simulations for the day are completed
        if let content = currentDayContent {
            // Check if all simulations in the content list are in our completed set
            let allCompleted = content.simulations.allSatisfy { completedSimulationIDs.contains($0.id) }
            
            if allCompleted {
                print("DEBUG: All simulations for Day \(day) completed.")
                
                // Mark today as completed in progress
                var progress = localStore.progress
                let todayStart = Calendar.current.startOfDay(for: Date())
                progress.lastCompletionDate[law.id] = todayStart
                localStore.saveProgress(progress)
                
                // We DO NOT advance day here anymore.
                // We wait for the next calendar day (handled in restoreState/checkAndAdvanceDays).
                
                // Check if we just finished day 3 (Law completed) - Logic for unlocking next law
                // This logic might also need to wait?
                // Actually, if they finished Day 3, they are technically "done" with the law.
                // But let's keep the daily rhythm. They finish Day 3 today, tomorrow they unlock the next law.
                // OR, we can unlock immediately but they can't start.
                // Let's stick to the rhythm: Finish Day 3 -> Wait for tomorrow -> Unlock next law & Start Day 1.
                
                // However, for better UX, maybe we show "Law Completed" immediately?
                // For now, let's keep it consistent: "Today's deduction completed".
                
            } else {
                // Not all simulations done yet
                print("DEBUG: Completed one simulation, moving to next in queue.")
            }
        }
        
        // Refresh state to show next simulation or next day
        restoreState()
    }
    
    private func calculateDailyScore(
        lawID: String,
        day: Int,
        type: RecordType,
        simulationScore: MindPentagon,
        checklistSelections: [String]
    ) -> MindPentagon {
        let checklistRaw = checklistScore(from: checklistSelections)
        let weighted = (simulationScore * DailyScoreConfig.simulationWeight) + (checklistRaw * DailyScoreConfig.checklistWeight)
        let scaled = weighted * DailyScoreConfig.simulationScale
        
        // Reflection text is archive-only; scoring comes from simulation/checklist.
        let sourceBounded: MindPentagon
        switch type {
        case .active, .passive, .factChecklist:
            sourceBounded = checklistRaw * (DailyScoreConfig.checklistScale * DailyScoreConfig.checklistWeight)
        case .simulation:
            sourceBounded = scaled
        }
        
        return applyDailyCaps(score: sourceBounded, lawID: lawID, day: day)
    }
    
    private func checklistScore(from selections: [String]) -> MindPentagon {
        selections.reduce(.zero) { partial, id in
            partial + checklistImpactMap[id, default: .zero]
        }
    }
    
    private var checklistImpactMap: [String: MindPentagon] {
        [
            "fact_pause_3s": MindPentagon(objectivity: 1, independence: 0, awareness: 2, decisiveness: 0, reflection: 1),
            "fact_identify_emotion": MindPentagon(objectivity: 0, independence: 0, awareness: 2, decisiveness: 0, reflection: 2),
            "fact_verify_assumption": MindPentagon(objectivity: 2, independence: 1, awareness: 1, decisiveness: 1, reflection: 1),
            "fact_boundary_expression": MindPentagon(objectivity: 1, independence: 2, awareness: 0, decisiveness: 2, reflection: 0),
            "fact_post_reflection": MindPentagon(objectivity: 1, independence: 0, awareness: 1, decisiveness: 0, reflection: 2)
        ]
    }
    
    private func applyDailyCaps(score: MindPentagon, lawID: String, day: Int) -> MindPentagon {
        let consumed = localStore.dailyRecords
            .filter {
                $0.lawID == lawID &&
                $0.dayNumber == day &&
                Calendar.current.isDate($0.createdAt, inSameDayAs: Date())
            }
            .reduce(.zero) { $0 + $1.scoreGained }
        
        var capped = score
        
        func capDimension(_ incoming: Double, consumed: Double) -> Double {
            guard incoming > 0 else { return incoming }
            let remaining = max(0, DailyScoreConfig.perDimensionDailyCap - max(0, consumed))
            return min(incoming, remaining)
        }
        
        capped.objectivity = capDimension(capped.objectivity, consumed: consumed.objectivity)
        capped.independence = capDimension(capped.independence, consumed: consumed.independence)
        capped.awareness = capDimension(capped.awareness, consumed: consumed.awareness)
        capped.decisiveness = capDimension(capped.decisiveness, consumed: consumed.decisiveness)
        capped.reflection = capDimension(capped.reflection, consumed: consumed.reflection)
        
        let totalUsed = consumed.positiveSum
        let totalIncoming = capped.positiveSum
        let totalRemaining = max(0, DailyScoreConfig.totalDailyCap - totalUsed)
        
        guard totalIncoming > totalRemaining, totalIncoming > 0 else {
            return capped
        }
        
        let factor = totalRemaining / totalIncoming
        return MindPentagon(
            objectivity: capped.objectivity > 0 ? capped.objectivity * factor : capped.objectivity,
            independence: capped.independence > 0 ? capped.independence * factor : capped.independence,
            awareness: capped.awareness > 0 ? capped.awareness * factor : capped.awareness,
            decisiveness: capped.decisiveness > 0 ? capped.decisiveness * factor : capped.decisiveness,
            reflection: capped.reflection > 0 ? capped.reflection * factor : capped.reflection
        )
    }
    
    var allLaws: [Law] {
        lawRepository.laws
    }
    
    var dailyFactChecklistItems: [FactChecklistItem] {
        [
            FactChecklistItem(id: "fact_pause_3s", title: "我在关键反应前停顿了至少3秒"),
            FactChecklistItem(id: "fact_identify_emotion", title: "我识别了自己当下的情绪"),
            FactChecklistItem(id: "fact_verify_assumption", title: "我核对了一个未经证实的假设"),
            FactChecklistItem(id: "fact_boundary_expression", title: "我表达了边界或真实偏好"),
            FactChecklistItem(id: "fact_post_reflection", title: "我在事件后做了复盘")
        ]
    }
    
    func switchCategory(_ newCategory: LawCategory) {
        guard newCategory != currentCategory else { return }
        
        // 1. Update Category
        self.currentCategory = newCategory
        UserDefaults.standard.set(newCategory.rawValue, forKey: "last_category")
        
        Task {
            // 2. Load data for new category
            await lawRepository.loadCategoryInitialData(category: newCategory.rawValue)
            
            await MainActor.run {
                // 3. Find the best law to resume in this category
                let categoryLaws = self.allLaws // Now contains laws for new category
                
                if categoryLaws.isEmpty {
                    print("DEBUG: No laws found for category \(newCategory.rawValue)")
                    // Clear active law to reflect empty state (or maybe keep old one but show error?)
                    // Better to clear so user knows it's empty
                    self.currentLaw = nil
                    return
                }
                
                // Find target law
                var targetLaw: Law? = nil
                
                // Logic: Find the highest index law that has been started (progress > 0)
                var lastActiveIndex = -1
                
                for (index, law) in categoryLaws.enumerated() {
                    let day = localStore.progress.lawProgress[law.id] ?? 0
                    if day > 0 {
                        lastActiveIndex = index
                    }
                }
                
                if lastActiveIndex != -1 {
                    let lastLaw = categoryLaws[lastActiveIndex]
                    let day = localStore.progress.lawProgress[lastLaw.id] ?? 0
                    
                    // If last active law is completed (Day >= 3), try to move to next
                    if day >= 3 {
                        if lastActiveIndex + 1 < categoryLaws.count {
                            targetLaw = categoryLaws[lastActiveIndex + 1]
                        } else {
                            // All done, stay on last
                            targetLaw = lastLaw
                        }
                    } else {
                        // Still in progress, resume this one
                        targetLaw = lastLaw
                    }
                } else {
                    // No progress at all, start first
                    targetLaw = categoryLaws.first
                }
                
                // 4. Update Global State
                if let law = targetLaw {
                    print("DEBUG: Switching category to \(newCategory.rawValue), target law: \(law.name)")
                    
                    var progress = localStore.progress
                    progress.activeLawID = law.id
                    
                    // Initialize if new
                    if progress.lawProgress[law.id] == nil {
                        progress.lawProgress[law.id] = 1
                    }
                    
                    // Ensure it's unlocked for viewing
                    progress.unlockedLawIDs.insert(law.id)
                    
                    localStore.saveProgress(progress)
                    
                    // 5. Trigger Restore
                    self.restoreState()
                }
            }
        }
    }

    func isLawUnlocked(_ lawID: String) -> Bool {
        return localStore.progress.unlockedLawIDs.contains(lawID)
    }
    
    // MARK: - Cloud Sync
    
    func syncWithCloud(uid: String) async {
        guard !isSyncing else { return }
        
        await MainActor.run { self.isSyncing = true }
        
        do {
            print("Sync: Starting sync for user \(uid)...")
            
            // 1. Try to fetch cloud progress
            if let cloudProgress = try await firestoreService.fetchProgress(uid: uid) {
                print("Sync: Cloud progress found. Overwriting local...")
                await MainActor.run {
                    self.localStore.saveProgress(cloudProgress)
                    self.restoreState() // Refresh UI
                }
            } else {
                print("Sync: No cloud progress. Uploading local...")
                // 2. If no cloud data, upload local data (new user or first sync)
                try await firestoreService.saveProgress(uid: uid, progress: localStore.progress)
            }
            
            // 3. Sync Daily Records (Optional for MVP, but good for backup)
            // For now, let's just upload new records as they are created (see submitDailyRecord)
            
            print("Sync: Complete.")
            
        } catch {
            print("Sync: Error syncing: \(error)")
        }
        
        await MainActor.run { self.isSyncing = false }
    }

    func deleteCurrentAccount(password: String) async throws {
        guard let currentUser = authService.currentUser else {
            throw NSError(
                domain: "AppViewModel",
                code: 401,
                userInfo: [NSLocalizedDescriptionKey: "当前没有已登录账号。"]
            )
        }

        let uid = currentUser.uid

        try await authService.reauthenticate(password: password)
        try await firestoreService.deleteUserData(uid: uid)
        try await authService.deleteAccount()

        await MainActor.run {
            self.localStore.resetProgress()
            self.currentLaw = nil
            self.currentDay = nil
            self.currentDayContent = nil
            self.selectedSimulation = nil
            self.completedSimulationIDs.removeAll()
            self.showOnboarding = true
            self.showPaywall = false
            self.isSyncing = false
        }
    }
    
    // MARK: - Access Control (The Lockdown)
    
    enum AppFeature {
        case archive
        case gothicStyle
        case mindPentagon
        case detailedAnalysis
        case reflection // New: Black Box / Writing Profile
    }
    
    func canAccessFeature(_ feature: AppFeature) -> Bool {
        if isPro { return true }
        if isTrialPeriod { return true }
        
        // Trial Expired & Not Pro
        switch feature {
        case .archive: return true // Archive Tab is OPEN
        case .gothicStyle: return false
        case .mindPentagon: return false
        case .detailedAnalysis: return false
        case .reflection: return false // Black Box is ALWAYS LOCKED after trial
        }
    }
    
    func canAccessContent(category: LawCategory, lawIndex: Int) -> Bool {
        if isPro { return true }
        if isTrialPeriod { return true }
        
        // Trial Expired & Not Pro
        // Only allow Social Influence (Category 1), First 3 Laws (Index 0, 1, 2)
        if category == .socialInfluence && lawIndex < 3 {
            return true
        }
        
        return false
    }
}
