import Foundation
import Combine

class LawRepository: ObservableObject {
    static let shared = LawRepository()
    private let fileManager = FileManager.default
    
    // Cache or storage for loaded laws
    @Published var laws: [Law] = []
    @Published var lastError: String? // Debugging
    
    private init() {}
    
    /// Loads the index for a given category and then loads all listed laws.
    func loadCategoryInitialData(category: String) async {
        guard let index = loadIndex(category: category) else {
            // If index load fails, clear current laws to reflect empty state
            await MainActor.run {
                self.laws = []
                self.lastError = "该板块暂无数据"
            }
            return
        }
        
        print("LawRepository: Index loaded, found \(index.laws.count) laws to fetch.")
        
        var loadedLaws: [Law] = []
        
        // Load each law referenced in the index
        // We can do this concurrently for speed
        await withTaskGroup(of: Law?.self) { group in
            for item in index.laws {
                group.addTask {
                    await self.loadLaw(category: category, id: item.id, displayName: item.name)
                }
            }
            
            for await law in group {
                if let law = law {
                    loadedLaws.append(law)
                }
            }
        }
        
        // Sort laws based on their order in the index (to preserve ordinality)
        // Or sort by ID if index order is not guaranteed
        let sortedLaws = loadedLaws.sorted { law1, law2 in
            let index1 = index.laws.firstIndex(where: { $0.id == law1.id }) ?? Int.max
            let index2 = index.laws.firstIndex(where: { $0.id == law2.id }) ?? Int.max
            return index1 < index2
        }
        
        await MainActor.run {
            self.laws = sortedLaws
            print("LawRepository: Successfully loaded \(self.laws.count) laws.")
            
            if self.laws.isEmpty {
                // Debugging: List bundle contents to see what's wrong
                let bundlePath = Bundle.main.bundlePath
                let fileManager = FileManager.default
                var debugMsg = "未加载到数据。\n\n"
                
                if let contents = try? fileManager.contentsOfDirectory(atPath: bundlePath) {
                    let jsonFiles = contents.filter { $0.contains("json") }
                    debugMsg += "Bundle根目录JSON文件 (\(jsonFiles.count)个):\n"
                    debugMsg += jsonFiles.prefix(10).joined(separator: "\n")
                    if jsonFiles.count > 10 { debugMsg += "\n...等" }
                }
                
                // Check data folder
                let dataPath = (bundlePath as NSString).appendingPathComponent("data/social_influence")
                if let dataContents = try? fileManager.contentsOfDirectory(atPath: dataPath) {
                    debugMsg += "\n\ndata/social_influence 目录:\n"
                    debugMsg += dataContents.prefix(10).joined(separator: "\n")
                } else {
                    debugMsg += "\n\n❌ 找不到 data/social_influence 目录"
                }
                
                self.lastError = debugMsg
            }
        }
    }
    
    /// Loads the index.json file
    private func loadIndex(category: String) -> LawIndexRootDTO? {
        let renamedIndex = "\(category)_index"
        
        // 1. Try subdirectory: "data/{category}" (If 'data' is a folder ref)
        if let bundleURL = Bundle.main.url(forResource: renamedIndex, withExtension: "json", subdirectory: "data/\(category)") {
            print("✅ Found index at data/\(category): \(bundleURL.path)")
            return decodeIndex(from: bundleURL)
        }
        
        // 2. Try subdirectory: "{category}" (If 'data' is a group and category is folder ref)
        if let bundleURL = Bundle.main.url(forResource: renamedIndex, withExtension: "json", subdirectory: category) {
            print("✅ Found index at \(category): \(bundleURL.path)")
            return decodeIndex(from: bundleURL)
        }
        
        // 3. Try root path (Flattened)
        if let bundleURL = Bundle.main.url(forResource: renamedIndex, withExtension: "json") {
            print("✅ Found index at root: \(bundleURL.path)")
            return decodeIndex(from: bundleURL)
        }

        // Legacy Fallbacks for "index.json"
        if let bundleURL = Bundle.main.url(forResource: "index", withExtension: "json", subdirectory: "data/\(category)") {
            return decodeIndex(from: bundleURL)
        }
        if let bundleURL = Bundle.main.url(forResource: "index", withExtension: "json", subdirectory: category) {
            return decodeIndex(from: bundleURL)
        }
        if let bundleURL = Bundle.main.url(forResource: "index", withExtension: "json") {
            if let index = decodeIndex(from: bundleURL), index.category == category {
                return index
            }
        }
        
        print("❌ LawRepository: Index not found for category \(category)")
        Task { @MainActor in self.lastError = "找不到索引文件 (\(category)_index.json)" }
        return nil
    }
    
    private func decodeIndex(from url: URL) -> LawIndexRootDTO? {
        do {
            let data = try Data(contentsOf: url)
            return try JSONDecoder().decode(LawIndexRootDTO.self, from: data)
        } catch {
            print("❌ LawRepository: Failed to decode index: \(error)")
            Task { @MainActor in self.lastError = "Index解码失败: \(error.localizedDescription)" }
            return nil
        }
    }
    
    /// Loads a single Law by aggregating its 5 component files
    /// Structure: data/social_influence/law_social_xxx/{law_social_xxx_base.json, etc}
    private func loadLaw(category: String, id: String, displayName: String? = nil) async -> Law? {
        // Paths to try
        let paths = ["data/\(category)/\(id)", "\(category)/\(id)", id]
        
        // Helper to load component
        func loadComponent<T: Decodable>(componentName: String, type: T.Type) -> T? {
            // Filename format: law_social_001_base.json
            let filename = "\(id)_\(componentName)"
            
            // Try all path combinations
            for path in paths {
                if let url = Bundle.main.url(forResource: filename, withExtension: "json", subdirectory: path) {
                    return decode(url: url, type: type)
                }
            }
            
            // Try root
            if let url = Bundle.main.url(forResource: filename, withExtension: "json") {
                return decode(url: url, type: type)
            }
            
            print("⚠️ Missing component \(filename) for \(id)")
            Task { @MainActor in 
                if self.lastError == nil { self.lastError = "缺失文件: \(filename)" }
            }
            return nil
        }
        
        func decode<T: Decodable>(url: URL, type: T.Type) -> T? {
            do {
                let data = try Data(contentsOf: url)
                return try JSONDecoder().decode(T.self, from: data)
            } catch {
                print("❌ Failed to decode \(url.lastPathComponent): \(error)")
                return nil
            }
        }
        
        // Load Base
        guard let base = loadComponent(componentName: "base", type: LawBaseDTO.self) else {
            print("❌ Base info missing for \(id), skipping law.")
            return nil
        }
        
        // Load Encyclopedia (Source/DeepDive)
        let encyclopedia = loadComponent(componentName: "encyclopedia", type: EncyclopediaDTO.self)
        
        // Load Days
        let day1 = loadComponent(componentName: "day1", type: DaySimulationDTO.self)
        let day2 = loadComponent(componentName: "day2", type: DaySimulationDTO.self)
        let day3 = loadComponent(componentName: "day3", type: DaySimulationDTO.self)
        
        // Assemble Domain Model
        var dayStages: [Law.DayContent] = []
        if let d1 = day1 { dayStages.append(d1.toDomain(dayNum: 1)) }
        if let d2 = day2 { dayStages.append(d2.toDomain(dayNum: 2)) }
        if let d3 = day3 { dayStages.append(d3.toDomain(dayNum: 3)) }
        
        // Ensure we have at least some content
        guard !dayStages.isEmpty else {
            print("⚠️ No days loaded for \(id)")
            return nil
        }
        
        let resolvedName = displayName?.trimmingCharacters(in: .whitespacesAndNewlines)
        return Law(
            id: id,
            name: (resolvedName?.isEmpty == false ? resolvedName : nil) ?? base.name,
            category: LawCategory(rawValue: category) ?? .socialInfluence,
            scenarioID: id,
            dailyQuote: base.safeQuote,
            detailText: base.safeSummary,
            experimentGuide: "", // No longer used directly, or mapped to something else?
            source: encyclopedia?.toSource(),
            deepDive: encyclopedia?.toDeepDive(),
            dayStages: dayStages
        )
    }
    
    func getLaw(by id: String) -> Law? {
        return laws.first(where: { $0.id == id })
    }
}
