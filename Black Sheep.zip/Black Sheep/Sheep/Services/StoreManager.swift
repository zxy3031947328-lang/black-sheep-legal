import Foundation
import StoreKit
import Combine

@MainActor
class StoreManager: ObservableObject {
    static let shared = StoreManager()
    
    @Published var isPro: Bool = false
    @Published var products: [Product] = []
    @Published var purchaseState: PurchaseState = .idle
    @Published var transactionMsg: String = ""
    @Published var productsLoadState: ProductsLoadState = .idle
    
    // Define the product IDs for the subscription group and lifetime purchase
    private let productIDs = [
        "com.zengxinyu.blacksheep.pro.monthly",
        "com.zengxinyu.blacksheep.pro.yearly",
        "com.zengxinyu.blacksheep.pro.lifetime"
    ]
    
    var loadedProductIDs: [String] {
        products.map(\.id)
    }
    
    var missingProductIDs: [String] {
        let loadedIDs = Set(loadedProductIDs)
        return productIDs.filter { !loadedIDs.contains($0) }
    }
    
    private var updates: Task<Void, Never>? = nil
    
    enum PurchaseState: Equatable {
        case idle
        case purchasing
        case success
        case failed(String)
        case restored
    }

    enum ProductsLoadState: Equatable {
        case idle
        case loading
        case loaded
        case failed(String)
    }
    
    private init() {
        // Start listening for transaction updates
        updates = newTransactionListenerTask()
        
        // Check initial status
        Task {
            await updateCustomerProductStatus()
            await loadProducts()
        }
    }
    
    deinit {
        updates?.cancel()
    }
    
    // MARK: - Core Logic
    
    func loadProducts(force: Bool = false) async {
        if productsLoadState == .loading { return }
        if !force && !products.isEmpty { return }

        productsLoadState = .loading
        transactionMsg = ""

        do {
            let products = try await Product.products(for: productIDs)
            let orderMap = Dictionary(uniqueKeysWithValues: productIDs.enumerated().map { ($0.element, $0.offset) })
            self.products = products.sorted {
                orderMap[$0.id, default: Int.max] < orderMap[$1.id, default: Int.max]
            }
            if products.isEmpty {
                let msg = "未获取到可售商品，请检查 App Store Connect 中的商品 ID、内购状态、合同税务与当前安装包环境。"
                productsLoadState = .failed(msg)
                transactionMsg = "App Store 返回了 0 个商品。常见原因：商品 ID 不匹配、商品未上架可售、合同税务未完成，或当前不是有效的沙盒/TestFlight 环境。"
                print("StoreManager: Loaded 0 products.")
            } else {
                productsLoadState = .loaded
                if !missingProductIDs.isEmpty {
                    transactionMsg = "仅返回了部分商品：\(missingProductIDs.joined(separator: ", ")) 未返回。"
                }
                print("StoreManager: Loaded \(products.count) products.")
            }
        } catch {
            let message = "无法连接 App Store：\(error.localizedDescription)"
            productsLoadState = .failed(message)
            transactionMsg = "请求商品失败：\(error.localizedDescription)"
            print("StoreManager: Failed to load products: \(error)")
        }
    }
    
    func purchase(_ product: Product) async {
        purchaseState = .purchasing
        transactionMsg = ""
        
        do {
            let result = try await product.purchase()
            
            switch result {
            case .success(let verification):
                // Check if the transaction is verified
                switch verification {
                case .verified(let transaction):
                    await transaction.finish()
                    await updateCustomerProductStatus()
                    transactionMsg = "购买成功：\(transaction.productID)"
                    purchaseState = .success
                case .unverified:
                    transactionMsg = "订单验证失败"
                    purchaseState = .failed("订单验证失败")
                }
            case .userCancelled:
                transactionMsg = "用户已取消购买。"
                purchaseState = .idle
            case .pending:
                transactionMsg = "订单待确认，请稍后查看。"
                purchaseState = .purchasing // Waiting for approval
            @unknown default:
                transactionMsg = "未知错误"
                purchaseState = .failed("未知错误")
            }
        } catch {
            transactionMsg = error.localizedDescription
            purchaseState = .failed(error.localizedDescription)
        }
    }
    
    func restorePurchases() async {
        purchaseState = .purchasing
        transactionMsg = ""
        do {
            try await AppStore.sync()
            await updateCustomerProductStatus()
            if isPro {
                transactionMsg = "已恢复购买"
                purchaseState = .restored
            } else {
                transactionMsg = "未找到可恢复的购买记录"
                purchaseState = .failed("未找到可恢复的购买记录")
            }
        } catch {
            transactionMsg = error.localizedDescription
            purchaseState = .failed(error.localizedDescription)
        }
    }
    
    // MARK: - Internal Helpers
    
    private func updateCustomerProductStatus() async {
        var hasPro = false
        
        // Iterate through all of the user's purchased products
        // StoreKit 2 automatically handles expiration for subscriptions
        for await result in Transaction.currentEntitlements {
            if case .verified(let transaction) = result {
                if productIDs.contains(transaction.productID) {
                    hasPro = true
                }
            }
        }
        
        self.isPro = hasPro
        print("StoreManager: User is Pro? \(hasPro)")
    }
    
    private func newTransactionListenerTask() -> Task<Void, Never> {
        Task.detached {
            // Listen for transactions in the background
            for await result in Transaction.updates {
                if case .verified(let transaction) = result {
                    await transaction.finish()
                    await self.updateCustomerProductStatus()
                }
            }
        }
    }
}
