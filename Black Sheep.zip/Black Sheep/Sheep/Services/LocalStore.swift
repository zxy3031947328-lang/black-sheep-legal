import Foundation
import Combine

class LocalStore: ObservableObject {
    @Published var progress: UserProgress
    @Published var dailyRecords: [DailyRecord] = []
    
    private let progressKey = "user_progress_v3"
    private let recordsKey = "daily_records_v3"
    
    // Default initial state
    private let defaultProgress = UserProgress(
        activeLawID: nil,
        lawProgress: [:],
        totalStats: MindPentagon(),
        unlockedLawIDs: [],
        hasCompletedOnboarding: false
    )
    
    init() {
        // Load Progress
        if let data = UserDefaults.standard.data(forKey: progressKey) {
            do {
                let decoder = JSONDecoder()
                self.progress = try decoder.decode(UserProgress.self, from: data)
            } catch {
                print("Error loading progress: \(error)")
                self.progress = defaultProgress
            }
        } else {
            self.progress = defaultProgress
        }
        
        // Load Records
        if let data = UserDefaults.standard.data(forKey: recordsKey) {
            do {
                let decoder = JSONDecoder()
                self.dailyRecords = try decoder.decode([DailyRecord].self, from: data)
            } catch {
                print("Error loading records: \(error)")
                self.dailyRecords = []
            }
        }
    }
    
    // MARK: - Save Methods
    
    func saveProgress(_ newProgress: UserProgress) {
        self.progress = newProgress
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(newProgress)
            UserDefaults.standard.set(data, forKey: progressKey)
        } catch {
            print("Error saving progress: \(error)")
        }
    }
    
    func addRecord(_ record: DailyRecord) {
        self.dailyRecords.append(record)
        
        // Update total stats
        var currentStats = self.progress.totalStats
        currentStats = currentStats + record.scoreGained
        currentStats = currentStats.clamped(min: 0, max: 2000)
        
        var newProgress = self.progress
        newProgress.totalStats = currentStats
        
        saveProgress(newProgress)
        saveRecords()
    }
    
    private func saveRecords() {
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(self.dailyRecords)
            UserDefaults.standard.set(data, forKey: recordsKey)
        } catch {
            print("Error saving records: \(error)")
        }
    }
    
    // MARK: - Helpers
    
    func advanceDay(for lawID: String) {
        var currentDay = self.progress.lawProgress[lawID] ?? 0
        currentDay += 1
        
        var newProgress = self.progress
        newProgress.lawProgress[lawID] = currentDay
        
        // Check if finished (assuming 3 days per law for now)
        if currentDay >= 3 {
             newProgress.unlockedLawIDs.insert(lawID)
        }
        
        saveProgress(newProgress)
    }
    
    func resetProgress() {
        self.progress = defaultProgress
        self.dailyRecords = []
        saveProgress(defaultProgress)
        saveRecords()
    }
}
