import Foundation

class AssessmentService {
    static let shared = AssessmentService()
    
    private(set) var assessment: Assessment?
    
    init() {
        loadAssessment()
    }
    
    private func loadAssessment() {
        if let url = Bundle.main.url(forResource: "assessment", withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                self.assessment = try decoder.decode(Assessment.self, from: data)
            } catch {
                print("Error loading assessment: \(error)")
            }
        }
    }
    
    func calculateScore(answers: [String: Int]) -> MindPentagon {
        guard let questions = assessment?.questions else { return MindPentagon() }
        
        var rawScores: [String: Double] = [
            "objectivity": 0,
            "independence": 0,
            "awareness": 0,
            "decisiveness": 0,
            "reflection": 0
        ]
        var maxScores: [String: Double] = [
            "objectivity": 0,
            "independence": 0,
            "awareness": 0,
            "decisiveness": 0,
            "reflection": 0
        ]
        
        for question in questions {
            if let answerValue = answers[question.id] {
                let score = questionScore(answerValue: answerValue, type: question.effectiveScoringType)
                let maxScore = questionMaxScore(type: question.effectiveScoringType)
                
                if rawScores[question.category] != nil {
                    rawScores[question.category, default: 0] += score
                    maxScores[question.category, default: 0] += maxScore
                }
            }
        }
        
        func normalize(category: String) -> Double {
            let raw = rawScores[category, default: 0]
            let max = maxScores[category, default: 0]
            guard max > 0 else { return 400.0 }
            return (raw / max) * 2000.0
        }
        
        return MindPentagon(
            objectivity: normalize(category: "objectivity"),
            independence: normalize(category: "independence"),
            awareness: normalize(category: "awareness"),
            decisiveness: normalize(category: "decisiveness"),
            reflection: normalize(category: "reflection")
        )
    }
    
    private func questionScore(answerValue: Int, type: AssessmentScoringType) -> Double {
        let clamped = min(5, max(1, answerValue))
        switch type {
        case .linear:
            return Double(clamped - 1)
        case .reverse:
            return Double(5 - clamped)
        case .balanced:
            switch clamped {
            case 1: return 0
            case 2: return 2
            case 3: return 3
            case 4: return 2
            case 5: return 0
            default: return 0
            }
        }
    }
    
    private func questionMaxScore(type: AssessmentScoringType) -> Double {
        switch type {
        case .linear, .reverse:
            return 4
        case .balanced:
            return 3
        }
    }
}
