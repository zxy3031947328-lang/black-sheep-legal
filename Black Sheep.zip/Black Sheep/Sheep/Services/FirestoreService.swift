import Foundation
import FirebaseFirestore

class FirestoreService {
    static let shared = FirestoreService()
    
    private let db = Firestore.firestore()
    
    // Collections
    private var usersRef: CollectionReference {
        return db.collection("users")
    }
    
    // MARK: - User Profile Operations
    
    func saveUserProfile(_ user: UserProfile) async throws {
        guard let id = user.id else { return }
        try usersRef.document(id).setData(from: user)
    }
    
    func fetchUserProfile(uid: String) async throws -> UserProfile? {
        let docRef = usersRef.document(uid)
        let snapshot = try await docRef.getDocument()
        return try? snapshot.data(as: UserProfile.self)
    }
    
    // MARK: - Progress Sync Operations
    
    // Save full progress to cloud
    func saveProgress(uid: String, progress: UserProgress) async throws {
        // We'll store progress as a sub-collection or a field inside the user document?
        // Let's store it as a field inside the user document for simplicity (single document read)
        // OR as a separate document in a sub-collection "data/progress"
        
        // For atomic updates, let's put it in a sub-collection so it doesn't conflict with profile updates
        let progressRef = usersRef.document(uid).collection("data").document("progress")
        try progressRef.setData(from: progress)
    }
    
    // Load full progress from cloud
    func fetchProgress(uid: String) async throws -> UserProgress? {
        let progressRef = usersRef.document(uid).collection("data").document("progress")
        let snapshot = try await progressRef.getDocument()
        return try? snapshot.data(as: UserProgress.self)
    }
    
    // MARK: - Daily Records Sync
    
    // We can also sync daily records, but that might be a lot of documents.
    // For MVP, maybe we just sync the aggregate stats (UserProgress) and let daily records stay local?
    // User wants "account sync", implying if I switch phones, I see my history.
    // So we should sync daily records too.
    
    func saveDailyRecord(uid: String, record: DailyRecord) async throws {
        let recordsRef = usersRef.document(uid).collection("daily_records")
        // Use the record's UUID as the document ID
        try recordsRef.document(record.id.uuidString).setData(from: record)
    }
    
    func fetchDailyRecords(uid: String) async throws -> [DailyRecord] {
        let recordsRef = usersRef.document(uid).collection("daily_records")
        let snapshot = try await recordsRef.getDocuments()
        return snapshot.documents.compactMap { try? $0.data(as: DailyRecord.self) }
    }

    // MARK: - Delete Account Data

    func deleteUserData(uid: String) async throws {
        let userRef = usersRef.document(uid)
        let progressRef = userRef.collection("data").document("progress")
        let recordsRef = userRef.collection("daily_records")

        let recordsSnapshot = try await recordsRef.getDocuments()
        for document in recordsSnapshot.documents {
            try await document.reference.delete()
        }

        try await progressRef.delete()
        try await userRef.delete()
    }
}
