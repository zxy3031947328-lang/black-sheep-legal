import Foundation
import FirebaseAuth
import Combine

class AuthService: ObservableObject {
    static let shared = AuthService()
    
    private enum AuthTimeout {
        static let seconds: UInt64 = 15
    }
    
    @Published var currentUser: User?
    @Published var isAuthenticated: Bool = false
    @Published var authError: String?
    
    private var handle: AuthStateDidChangeListenerHandle?
    
    init() {
        // Listen to Auth State Changes
        handle = Auth.auth().addStateDidChangeListener { [weak self] (auth, user) in
            self?.currentUser = user
            self?.isAuthenticated = (user != nil)
        }
    }
    
    deinit {
        if let handle = handle {
            Auth.auth().removeStateDidChangeListener(handle)
        }
    }
    
    // MARK: - Sign Up (Email/Password)
    func signUp(email: String, password: String) async throws {
        do {
            let normalizedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            try await withTimeout(seconds: AuthTimeout.seconds) {
                let result = try await Auth.auth().createUser(withEmail: normalizedEmail, password: password)
                await MainActor.run {
                    self.currentUser = result.user
                    self.authError = nil
                }
            }
        } catch {
            await MainActor.run {
                self.authError = self.userFriendlyMessage(for: error)
            }
            throw NSError(domain: "AuthService", code: 1, userInfo: [
                NSLocalizedDescriptionKey: self.userFriendlyMessage(for: error)
            ])
        }
    }
    
    // MARK: - Sign In (Email/Password)
    func signIn(email: String, password: String) async throws {
        do {
            let normalizedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            try await withTimeout(seconds: AuthTimeout.seconds) {
                let result = try await Auth.auth().signIn(withEmail: normalizedEmail, password: password)
                await MainActor.run {
                    self.currentUser = result.user
                    self.authError = nil
                }
            }
        } catch {
            await MainActor.run {
                self.authError = self.userFriendlyMessage(for: error)
            }
            throw NSError(domain: "AuthService", code: 1, userInfo: [
                NSLocalizedDescriptionKey: self.userFriendlyMessage(for: error)
            ])
        }
    }
    
    // MARK: - Sign Out
    func signOut() async throws {
        do {
            try Auth.auth().signOut()
            await MainActor.run {
                self.currentUser = nil
                self.isAuthenticated = false
            }
        } catch {
            print("Error signing out: \(error)")
            throw error
        }
    }
    
    // MARK: - Password Reset
    func sendPasswordReset(email: String) async throws {
        let normalizedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        try await withTimeout(seconds: AuthTimeout.seconds) {
            try await Auth.auth().sendPasswordReset(withEmail: normalizedEmail)
        }
    }

    // MARK: - Reauthenticate
    func reauthenticate(password: String) async throws {
        guard let user = Auth.auth().currentUser,
              let email = user.email else {
            throw NSError(
                domain: "AuthService",
                code: 401,
                userInfo: [NSLocalizedDescriptionKey: "当前账号不是邮箱登录，无法执行删除账号。"]
            )
        }

        let credential = EmailAuthProvider.credential(withEmail: email, password: password)
        try await user.reauthenticate(with: credential)
    }
    
    // MARK: - Delete Account
    func deleteAccount() async throws {
        guard let user = Auth.auth().currentUser else { return }
        try await user.delete()
        await MainActor.run {
            self.currentUser = nil
            self.isAuthenticated = false
        }
    }
    
    private func withTimeout<T>(
        seconds: UInt64,
        operation: @escaping @Sendable () async throws -> T
    ) async throws -> T {
        try await withThrowingTaskGroup(of: T.self) { group in
            group.addTask {
                try await operation()
            }
            group.addTask {
                try await Task.sleep(nanoseconds: seconds * 1_000_000_000)
                throw NSError(
                    domain: "AuthService",
                    code: 408,
                    userInfo: [NSLocalizedDescriptionKey: "请求超时，请检查网络、VPN 或 Firebase 配置。"]
                )
            }
            
            let result = try await group.next()!
            group.cancelAll()
            return result
        }
    }
    
    private func userFriendlyMessage(for error: Error) -> String {
        let nsError = error as NSError
        
        guard nsError.domain == AuthErrorDomain,
              let code = AuthErrorCode(rawValue: nsError.code) else {
            return error.localizedDescription
        }
        
        switch code {
        case .invalidEmail:
            return "邮箱格式不正确。"
        case .emailAlreadyInUse:
            return "该邮箱已被注册。"
        case .wrongPassword, .invalidCredential:
            return "邮箱或密码不正确。"
        case .userNotFound:
            return "该账号不存在。"
        case .weakPassword:
            return "密码强度太弱，请至少使用 6 位字符。"
        case .networkError:
            return "网络异常，请检查网络后重试。"
        case .tooManyRequests:
            return "请求过于频繁，请稍后再试。"
        case .operationNotAllowed:
            return "Firebase 控制台可能尚未开启邮箱密码登录。"
        default:
            return error.localizedDescription
        }
    }
}
