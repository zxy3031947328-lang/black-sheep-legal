import SwiftUI

// MARK: - Gothic Theme Colors
// Shared color definitions for the Gothic Vintage + Grunge theme
extension Color {
    static let gothicBackgroundStart = Color(red: 0.05, green: 0.05, blue: 0.05) // 更深
    static let gothicBackgroundEnd = Color.black
    static let gothicCardPaper = Color(red: 0.88, green: 0.84, blue: 0.75)       // 提亮纸张，增加对比度
    static let gothicCardEdge = Color(red: 0.75, green: 0.70, blue: 0.60)        // 边缘跟随提亮
    static let gothicTextInk = Color(red: 0.05, green: 0.02, blue: 0.02)         // 墨色更深，接近纯黑
    static let gothicAccentRed = Color(red: 0.65, green: 0.15, blue: 0.15)       // 红点缀稍微提亮
    static let gothicTextFaded = Color(red: 0.60, green: 0.55, blue: 0.50)       // 恢复暖色调的褪色字迹，并略微提亮以适配深色背景
}
