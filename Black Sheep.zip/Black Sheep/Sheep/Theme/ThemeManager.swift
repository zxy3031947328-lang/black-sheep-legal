import SwiftUI

// MARK: - UI Style Enum
enum UIStyle: String, CaseIterable {
    case gothic = "Gothic"
    case minimalist = "Minimalist"
}

// MARK: - Theme Protocol
// This protocol defines the semantic color system that all views should use.
protocol AppTheme {
    var style: UIStyle { get }
    
    // Core Backgrounds
    var backgroundMain: Color { get }       // The deepest background (behind everything)
    var backgroundContent: Color { get }    // The background for scrollable content areas
    
    // Text Colors
    var textPrimary: Color { get }          // Main content text
    var textSecondary: Color { get }        // Subtitles, metadata
    var textTertiary: Color { get }         // Disabled, hints
    
    // Interactive Colors
    var accent: Color { get }               // Interactive elements, highlights
    var accentDestructive: Color { get }    // Errors, warnings
    
    // Card Specifics
    // Since cards have complex gradients in Gothic mode, we use AnyShapeStyle
    func cardBackground(isDark: Bool) -> AnyShapeStyle
    var cardBorder: Color { get }
    var cardShadow: Color { get }
    var cardCornerRadius: CGFloat { get }
    
    // Typography Design
    var fontDesign: Font.Design { get }
    
    // Visual Effects
    var showGrain: Bool { get }             // Whether to show noise/grain
    var showInnerGlow: Bool { get }         // Whether to show inner highlights
    var showEdgeBurn: Bool { get }          // Whether to show burnt edges
    
    // Content Visibility
    var showSectionHeaders: Bool { get }    // Whether to show decorative headers like "今日推演"
    
    // Text Labels
    var labelViewClues: String { get }      // 查看线索 / 实践建议
    var labelWriteProfile: String { get }   // 撰写侧写 / 黑匣子
    var labelID: String { get }             // 代号 / 昵称
    var labelLevel: String { get }          // 级别 / 等级
    var labelNo: String { get }             // 编号 / ID
    var labelJoined: String { get }         // 注册 / 加入时间
    var labelTitleMe: String { get }        // 调查员证件 / (隐藏)
    var labelLevelSuffix: String { get }    // " 观察者" / ""
    var labelClueCard: String { get }       // 线索卡 / 机制详解
    
    // Icons & Stamps
    var iconWriteProfile: String { get }    // pencil... / cube.fill
    var iconViewClues: String { get }       // arrow.right / chevron.right
    var showAuthStamp: Bool { get }         // true / false
    
    // Formatting Prefixes
    var idPrefix: String { get }            // "NO." / ""
    var levelPrefix: String { get }         // "Level " / ""
    
    // Archive / Achievements Labels
    var labelSectionDecrypted: String { get } // 已解密档案 / 档案库
    var labelSectionPrinciple: String { get } // 原理解析 / 机制核心
    var labelSectionNotes: String { get }     // 调查员笔记 / 记录
    var labelNoRecords: String { get }        // 暂无现场记录... / 无记录
    var labelSwitchToLaw: String { get }      // 调取此档案 / 切换至此
}

// MARK: - Gothic Theme Implementation (Original)
struct GothicThemeImpl: AppTheme {
    let style: UIStyle = .gothic
    
    var backgroundMain: Color { Color.gothicBackgroundStart }
    var backgroundContent: Color { Color.clear } // Handled by global background layer
    
    var textPrimary: Color { Color.gothicTextInk }
    var textSecondary: Color { Color.gothicTextFaded }
    var textTertiary: Color { Color.gothicTextFaded.opacity(0.6) }
    
    var accent: Color { Color.gothicAccentRed }
    var accentDestructive: Color { Color.red.opacity(0.8) }
    
    func cardBackground(isDark: Bool) -> AnyShapeStyle {
        AnyShapeStyle(
            RadialGradient(
                gradient: Gradient(colors: [Color.gothicCardPaper, Color.gothicCardEdge]),
                center: .center,
                startRadius: 2,
                endRadius: 300
            )
        )
    }
    
    var cardBorder: Color { Color.black.opacity(0.15) }
    var cardShadow: Color { Color.black.opacity(0.4) }
    var cardCornerRadius: CGFloat { 4.0 }
    
    var fontDesign: Font.Design { .serif }
    
    var showGrain: Bool { true }
    var showInnerGlow: Bool { true }
    var showEdgeBurn: Bool { true }
    
    var showSectionHeaders: Bool { true }
    
    // Labels
    var labelViewClues: String { "查看线索" }
    var labelWriteProfile: String { "撰写侧写" }
    var labelID: String { "代号" }
    var labelLevel: String { "级别" }
    var labelNo: String { "编号" }
    var labelJoined: String { "注册" }
    var labelTitleMe: String { "调查员证件" }
    var labelLevelSuffix: String { " 观察者" }
    var labelClueCard: String { "线索卡" } // Used as prefix in Gothic
    
    // Icons & Stamps
    var iconWriteProfile: String { "pencil.tip.crop.circle" }
    var iconViewClues: String { "arrow.right" }
    var showAuthStamp: Bool { true }
    
    // Formatting Prefixes
    var idPrefix: String { "NO." }
    var levelPrefix: String { "Level " }
    
    // Archive Labels
    var labelSectionDecrypted: String { "已解密档案" }
    var labelSectionPrinciple: String { "【原理解析】" }
    var labelSectionNotes: String { "【调查员笔记】" }
    var labelNoRecords: String { "暂无现场记录..." }
    var labelSwitchToLaw: String { "调取此档案" }
}

// MARK: - Minimalist Theme Implementation (Modern)
struct MinimalistThemeImpl: AppTheme {
    let style: UIStyle = .minimalist
    
    // Dependencies injected via method calls if needed, or static properties
    // We'll rely on the caller passing `isDark` context where necessary for dynamic resolution,
    // or return a color that adapts automatically to system traitCollection (UIColor).
    // However, since we are doing custom "Light/Dark" based on time/system, let's keep it simple.
    
    // We will use a helper to resolve light/dark colors based on the *System* color scheme.
    // Ideally, for "Night Mode", the app might want to force dark mode, but let's stick to system adaptivity first.
    
    // Dynamic Colors Helpers
    private func dynamicColor(light: Color, dark: Color) -> Color {
        Color(UIColor { traitCollection in
            return traitCollection.userInterfaceStyle == .dark ? UIColor(dark) : UIColor(light)
        })
    }
    
    // Light Mode: Alabaster White
    // Dark Mode: True Black
    var backgroundMain_Light: Color { Color(white: 0.96) } // Slightly darker white for contrast
    var backgroundMain_Dark: Color { Color.black }
    
    var backgroundMain: Color {
        dynamicColor(light: backgroundMain_Light, dark: backgroundMain_Dark)
    }
    
    var backgroundContent: Color { Color.clear }
    
    var textPrimary: Color {
        dynamicColor(light: Color(hex: "1C1C1E"), dark: .white)
    }
    
    var textSecondary: Color {
        dynamicColor(light: Color.gray, dark: Color.gray)
    }
    
    var textTertiary: Color {
        dynamicColor(light: Color.gray.opacity(0.5), dark: Color.gray.opacity(0.5))
    }
    
    var accent: Color {
        // Day: Bronze Gold, Night: Alert Red
        // Adjusted Gold for better visibility on white (Darker than C5A028)
        dynamicColor(light: Color(hex: "9C7C18"), dark: Color(hex: "FF3B30"))
    }
    
    var accentDestructive: Color { Color.red }
    
    func cardBackground(isDark: Bool) -> AnyShapeStyle {
        // Light: Pure White
        // Dark: Dark Gray (Elevated)
        let color = isDark ? Color(hex: "1C1C1E") : Color.white
        return AnyShapeStyle(color)
    }
    
    var cardBorder: Color {
        dynamicColor(light: Color.black.opacity(0.05), dark: Color.white.opacity(0.1))
    }
    
    var cardShadow: Color {
        dynamicColor(light: Color.black.opacity(0.08), dark: Color.clear)
    }
    
    var cardCornerRadius: CGFloat { 24.0 } // Large modern radius
    
    var fontDesign: Font.Design { .default } // System San-Serif
    
    var showGrain: Bool { false }
    var showInnerGlow: Bool { false }
    var showEdgeBurn: Bool { false }
    
    var showSectionHeaders: Bool { false } // Hide "Today's Deduction" etc.
    
    // Labels
    var labelViewClues: String { "实践建议" }
    var labelWriteProfile: String { "黑匣子" }
    var labelID: String { "昵称" }
    var labelLevel: String { "等级" }
    var labelNo: String { "ID" }
    var labelJoined: String { "加入时间" }
    var labelTitleMe: String { "" } // Hidden
    var labelLevelSuffix: String { "" } // Hidden
    var labelClueCard: String { "" } // Unused in minimalist, we show Law Name
    
    // Icons & Stamps
    var iconWriteProfile: String { "cube.fill" } // Black Box icon
    var iconViewClues: String { "chevron.right" }
    var showAuthStamp: Bool { false }
    
    // Formatting Prefixes
    var idPrefix: String { "" }
    var levelPrefix: String { "" }
    
    // Archive Labels
    var labelSectionDecrypted: String { "档案库" }
    var labelSectionPrinciple: String { "机制核心" }
    var labelSectionNotes: String { "记录" }
    var labelNoRecords: String { "无记录" }
    var labelSwitchToLaw: String { "切换至此" }
}

// MARK: - Hex Color Helper
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (1, 1, 1, 0)
        }
        
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue:  Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}
