import SwiftUI

//  Black Sheep
//
//  Created by 曾鑫宇 on 2026/2/26.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = AppViewModel()
    
    var body: some View {
        MainTabView(viewModel: viewModel)
            .tint(Color(red: 0.5, green: 0.5, blue: 0.5)) // Use explicit modern tint API
    }
}
